package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Product;
import com.example.demo.service.ProductService;

@RestController
public class ProductController {

	@Autowired
	private ProductService productservice;
	
	@GetMapping("/getproduct")
	public List<Product> getAllProduct(){
		return productservice.getAllProduct();
	}
	
	@PostMapping("/addproduct")
	public Product addProduct(@RequestBody Product product) {
		return productservice.addProduct(product);
	}
	
	@PutMapping("/product/{pid}/customer/{cid}")
	public Product enrolledCustomerToProduct(@PathVariable("pid") Integer pid, @PathVariable("cid") Integer cid) {
		return productservice.enrolledCustomerToProduct(pid, cid);
	}
}
