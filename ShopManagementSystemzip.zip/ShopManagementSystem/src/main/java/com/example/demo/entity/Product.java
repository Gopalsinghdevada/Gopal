package com.example.demo.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

@Entity
public class Product {
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer productId;
	private String productName;
	private float productPrice;
	//relation
	@ManyToMany
	@JoinTable(name = "customer_enrolled", joinColumns = @JoinColumn(name = "product_id"),
	inverseJoinColumns = @JoinColumn(name = "customer_id"))
	Set<Customer>enrolledcustomer=new HashSet<>();
	
	public Set<Customer> getEnrolledcustomer() {
		return enrolledcustomer;
	}
	public void setEnrolledcustomer(Set<Customer> enrolledcustomer) {
		this.enrolledcustomer = enrolledcustomer;
	}
	public Integer getProductId() {
		return productId;
	}
	public void setProductId(Integer productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public float getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(float productPrice) {
		this.productPrice = productPrice;
	}
	public void enrolledcustomer(Customer customer) {
		enrolledcustomer.add(customer);
		
	}
	
}
