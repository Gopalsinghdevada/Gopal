package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Customer;
import com.example.demo.entity.Product;
import com.example.demo.repository.CustomerRepository;
import com.example.demo.repository.ProductRepository;

@Service
public class ProductServiceimpl implements ProductService{

	@Autowired
	private ProductRepository productRepository;
	@Autowired
	private CustomerRepository customerRepository;
	@Override
	public List<Product> getAllProduct() {
		
		return productRepository.findAll();
	}
	@Override
	public Product addProduct(Product product) {
		
		return productRepository.save(product);
	}
	@Override
	public Product enrolledCustomerToProduct(Integer pid, Integer cid) {
		Product product=productRepository.findById(pid).get();
		Customer customer=customerRepository.findById(cid).get();
		product.enrolledcustomer(customer);
		return productRepository.save(product);
	}

}
