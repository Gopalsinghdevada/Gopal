package com.edu;

import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;


public class TreeMapItera {

	public static void main(String[] args) {
		TreeMap<String,String> lob=new TreeMap<String,String>();
		int num;
		String j;
		Scanner sc=new Scanner(System.in);
		System.out.println("How many members u want to enter");
		num=sc.nextInt();
		System.out.println("Enter  "+num+" elements");
		for(int i=0;i<num;i++) {
		//	j=sc.nextInt();
		//	lob.add(j);
			
			String ph=sc.next();
			String nm=sc.next();
			lob.put(ph,nm);
			
		}
		for(Map.Entry<String, String> eob:lob.entrySet()) {
			System.out.println(eob.getKey()+"\t" +eob.getValue());
		}
		
	}

}
