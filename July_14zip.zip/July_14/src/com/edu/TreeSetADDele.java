package com.edu;

import java.util.Iterator;

import java.util.Scanner;
import java.util.TreeSet;

public class TreeSetADDele {

	public static void main(String[] args) {
		TreeSet<String> lob=new TreeSet<String>();
		int num;
		Scanner sc=new Scanner(System.in);
		System.out.println("How many name u want to enter");
		num=sc.nextInt();
		System.out.println("Enter  "+num+" elements");
		for(int i=0;i<=num;i++) {
		//	j=sc.nextInt();
		//	lob.add(j);
			lob.add(sc.nextLine());
		}
		
		Iterator<String> itob=lob.iterator();
		while(itob.hasNext()) {
			System.out.println(itob.next());
		}
		
	}

}
