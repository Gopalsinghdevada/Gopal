package com.edu;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.Scanner;

public class LinkedListMain1 {

	public static void main(String[] args) {
		LinkedList<Integer> lob=new LinkedList<Integer>();
		int num,j=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("How many number u want to enter");
		num=sc.nextInt();
		System.out.println("Enter  "+num+" elements");
		for(int i=0;i<num;i++) {
		//	j=sc.nextInt();
		//	lob.add(j);
			lob.add(sc.nextInt());
		}
		
		Iterator<Integer> itob=lob.iterator();
		while(itob.hasNext()) {
			System.out.println(itob.next());
		}
		
		
	}
}

