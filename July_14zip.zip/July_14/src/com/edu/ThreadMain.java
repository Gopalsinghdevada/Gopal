package com.edu;

class Employee{
	
}
class Firstclass  implements Runnable{

	@Override
	public void run() {
		for(int i=1;i<=5;i++) {
		System.out.println(Thread.currentThread());
		}
	}

}

public class ThreadMain {

	public static void main(String[] args) {
		System.out.println(Thread.currentThread());
		Firstclass ob=new Firstclass();
		Firstclass ob1=new Firstclass();
		Thread tob=new Thread(ob);
		Thread tob1=new Thread(ob);
		tob.setName("FirstThread");
		tob1.setName("SecondThread");
		tob.start();
		tob1.start();
		

	}

}
