package com.edu;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.TreeSet;



public class RemoveDuplicateMain {

	public static void main(String[] args) {
		ArrayList<String> lob=new ArrayList();
        lob.add("Gopal");
        lob.add("Divya");
        lob.add("Neha");
        lob.add("Gopal");
        lob.add("Rahul");
        System.out.println(lob);
        
         TreeSet<String> ts=new TreeSet<String>(lob);
         Iterator<String> itob=ts.iterator();
         while(itob.hasNext()) {
        	 System.out.println(itob.next());
         }
	}

}
