package com.edu;

public class WhileLoop {

	public static void main(String[] args) {
		int i=1;
		while(i<=10) {
			System.out.println(i+"Gopalsingh");
			i++;
		}
		System.out.println(i);
	}

}
