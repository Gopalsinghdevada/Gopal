package com.edu;

import java.util.Scanner;

class Reverse{
	 int d,num,rev,temp;
	 
void operation() {
	 Scanner sc = new Scanner(System.in);
	 System.out.println("Enter number");
	 num=sc.nextInt();
	 temp=num;
	 while(num>0) {
		 d=num%10;
		 rev=rev*10+d;
		 num=num/10;
		
	 }
	 System.out.println(rev);
	 }

    void palindrome() {
	if(rev==temp) {
		System.out.println("Entered number is palindrome");
	}else {
		System.out.println("Not a palindrome");
	}
}
}

public class ReverseNumber {

	public static void main(String[] args) {
		Reverse re = new Reverse();
		re.operation();
		re.palindrome();
	}

}
 