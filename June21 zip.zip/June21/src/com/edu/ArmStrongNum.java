package com.edu;

import java.util.Scanner;
  
  class Arms{
	int num, temp;
	void inputData()
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number:");
		num=sc.nextInt();
		}
	void checkArm() {
		temp=num;
		int digit=0;
		int	s=0;
		while(temp>0) {
			digit=temp%10;
			s=s+(digit*digit*digit);
			temp=temp/10;
		}
		if(num==s) {
			System.out.println(num+" is armstrong number");
		}
		else {
			System.out.println(num+" is not armstrong number");
		}
	}
	
}

public class ArmStrongNum {

	public static void main(String[] args) {
	   Arms arm1 = new Arms();
	   arm1.inputData();
	   arm1.checkArm();
		 }
	}


