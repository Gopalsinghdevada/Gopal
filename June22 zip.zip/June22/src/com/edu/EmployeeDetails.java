package com.edu;

import java.util.Scanner;

public class EmployeeDetails {

	public static void main(String[] args) {
		String name;
		int age;
		double salary;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter name of employee");
		name=sc.nextLine();
		
		System.out.println("Enter age of employee");
		age=sc.nextInt();
		System.out.println("Enter salary of employee");
		salary=sc.nextDouble();
		
		System.out.println("Name of employee is " +name);
		System.out.println("Age of employee is " +age);
		System.out.println("Salary of employee is " +salary);
	}

}
