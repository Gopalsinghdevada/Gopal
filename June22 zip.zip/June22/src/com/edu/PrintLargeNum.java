package com.edu;

import java.util.Scanner;

public class PrintLargeNum {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int a,b;
		System.out.println("Enter a");
		a=sc.nextInt();
		System.out.println("Enter b");
		b=sc.nextInt();
		if(a>b) {
			System.out.println("The larger number is a "+a);
		}
		 if(b>a)
		{
			System.out.println("The larger number is b "+b);
		}
		if(a==b)
		{
			System.out.println("Both are equal");
		}
		
	}

}
