package com.edu;

import java.util.Scanner;

public class ArrayMaxNum {

	public static void main(String[] args) {
		int a[];
		int size;
		int i;
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter size");
		size=sc.nextInt();
		a=new int[size];
		System.out.println("Enter array elements"+a.length);
		for(i=0;i<a.length;i++) {
			a[i]=sc.nextInt();
		}
		System.out.println("array elements are");
		for( i=0;i<a.length;i++){
			System.out.println(a[i]);
}
	//largest array
		int max=a[0];
		for(i=1;i<a.length;i++) {
			if(a[i]>max) {
				max=a[i];
			}
		}
		System.out.println("largest array element is" +max);
	}

}
