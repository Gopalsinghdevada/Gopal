//Linear search workes even if data is sorted or not.
package com.edu;

import java.util.Scanner;

public class LinearSearch {

	public static void main(String[] args) {
		int a[];
		int size;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter size");
		size=sc.nextInt();
		a=new int[size];
		System.out.println("Enter array elements"+a.length);
		for(int  i=0;i<a.length;i++) {
			a[i]=sc.nextInt();
		}
		System.out.println("array elements are");
		for(int i:a){
			System.out.println(i);
		}
		int find;
		int i;
		System.out.println("Enter element u want to find");
		find=sc.nextInt();
		
		for(i=0;i<size;i++) {
			if(a[i]==find) {
				System.out.println("Element found at index no."+i);
				break;
			}
		}
		if(i==size) {
			System.out.println("Element not found");
		}

	}

}
