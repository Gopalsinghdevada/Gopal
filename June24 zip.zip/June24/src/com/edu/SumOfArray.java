package com.edu;

import java.util.Scanner;

public class SumOfArray {

	public static void main(String[] args) {
		int a[];
		int size;
		int sum=0;
		int i;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter size");
		size=sc.nextInt();
		a=new int[size];
		System.out.println("Enter array elements"+a.length);
		for(i=0;i<a.length;i++) {
			a[i]=sc.nextInt();
		}
		System.out.println("array elements are");
		for( i=0;i<a.length;i++){
			 sum=sum+a[i];
			 
			 
		}
		
		System.out.println(sum);
	}

}
