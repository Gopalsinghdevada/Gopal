package com.edu;

import java.util.Scanner;

public class BubbleSorting {

	public static void main(String[] args) {
		int a[];
		int size;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter size");
		size=sc.nextInt();
		a=new int[size];
		System.out.println("Enter array elements"+a.length);
		for(int i=0;i<a.length;i++) {
			a[i]=sc.nextInt();
		}
		System.out.println("array elements are");
		for(int i:a){
			System.out.println(i);
			}
		System.out.println("bubble sorted array elements are:");
		int temp;
		for(int i=0;i<size;i++) {
			for(int j=0;j<size-1-i;j++) {
				if(a[j]>a[j+1]) {
					temp=a[j];
					a[j]=a[j+1];
					a[j+1]=temp;
				}
			}
		}
		for(int i=0;i<size;i++) {
			System.out.println(a[i]+" ");
		}
	}

}
