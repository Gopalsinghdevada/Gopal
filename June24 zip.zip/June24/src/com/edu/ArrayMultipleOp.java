package com.edu;

import java.util.Scanner;

class ArrayOperation{
	int a[];
	int size;
	int i,sum;
	
	public void inputData() {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter size");
	size=sc.nextInt();
	a=new int[size];
	System.out.println("Enter array elements"+a.length);
	for(i=0;i<a.length;i++) {
		a[i]=sc.nextInt();
	}
	} //inputData
	public void displayArrayElements() {
		System.out.println("array elements are");
		for( i=0;i<a.length;i++){
			System.out.println(a[i]);
			 sum=sum+a[i];
			 
			 
		}
	}
	public void largetElement() {
		//largest array
				int max=a[0];
				for(i=1;i<a.length;i++) {
					if(a[i]>max) {
						max=a[i];
					}
				}
				System.out.println("largest array element is" +max);
		
	}//largest
	
	public void leastElement() {
		//smallest array
				int min=a[0];
				for(i=1;i<a.length;i++) {
					if(a[i]<min) {
						min=a[i];
					}
				}
				System.out.println("Smallest array element is " +min);

	}
	
	//average
	public void arrayAverage() {
		float avg=(float)sum / size;
		System.out.println("Average is "+avg);
		
	}
	
}

class DummyClass{
	
	public void dummyMethod() {
		System.out.println("DummyClass method");
		ArrayOperation ob = new ArrayOperation();
		ob.inputData();
		ob.displayArrayElements();
	}
}
public class ArrayMultipleOp {

	public static void main(String[] args) {
		ArrayOperation arraobj = new ArrayOperation();
		arraobj.inputData();
		arraobj.displayArrayElements();
		arraobj.largetElement();
		arraobj.leastElement();
		arraobj.arrayAverage();
		
		DummyClass dob = new DummyClass();
		dob.dummyMethod();
		

	}

}
