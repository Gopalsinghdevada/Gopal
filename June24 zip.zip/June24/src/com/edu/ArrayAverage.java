package com.edu;

import java.util.Scanner;

public class ArrayAverage {

	public static void main(String[] args) {
		int a[];
		int size;
		int sum=0;
		int i,avg;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter size");
		size=sc.nextInt();
		a=new int[size];
		System.out.println("Enter array elements"+a.length);
		for(i=0;i<a.length;i++) {
			a[i]=sc.nextInt();
		}
		System.out.println("array elements are");
		for( i=0;i<a.length;i++){
			System.out.println(a[i]);
			 sum=sum+a[i];
			 
			 
		}
		
		System.out.println("Sum of array is "+sum);
		avg=sum / size;
		System.out.println("Average is "+avg);
		

	}

}
