package com.edu;

public class ArrayTut {

	public static void main(String[] args) {
		int arr[]= {3,7,8,9};//intialization
		/*for(int i=arr.length-1;i>=0;i--)
		System.out.println(arr[i]);

	}*/
	//for each
	for(int i:arr) { //enhanced foor loop
		System.out.println(i);
	}

	}
}