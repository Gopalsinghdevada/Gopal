// for binary search data must be sorted if not then sort it.
//binary search is faster than linear search.
package com.edu;

import java.util.Scanner;

public class BinarySearch {

	public static void main(String[] args) {
		int a[];
		int size;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter size");
		size=sc.nextInt();
		a=new int[size];
		System.out.println("Enter array elements"+a.length);
		for(int i=0;i<a.length;i++) {
			a[i]=sc.nextInt();
		}
		System.out.println("array elements are");
		for(int i:a){
			System.out.println(i);
			}
		
		int find;
	    System.out.println("Enter element u want to find");
		find=sc.nextInt();
		System.out.println("Enter element u want to find is "+find);
		int li=0;
		int hi=size-1;
		int mid=(li+hi)/2;
		
		while(li<hi) {
		if(a[mid]==find)
		{
			System.out.println("Element is at "+mid+" index position");
			break;
			}
		else if(a[mid]<find) {
			li=mid+1;
			}
		else
		{
			hi=mid-1;
		}
	    mid=(li+hi)/2;
		}
	 System.out.println(find+"  Element not found");
		  
		}
	}


