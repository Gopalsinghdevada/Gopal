package com.edu;

import java.util.Scanner;

public class ArrayTut2 {

	public static void main(String[] args) {
		int a[];
		int size;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter size");
		size=sc.nextInt();
		a=new int[size];
		System.out.println("Enter array elements"+a.length);
		for(int i=0;i<a.length;i++) {
			a[i]=sc.nextInt();
		}
		System.out.println("array elements are");
		for(int i:a){
			System.out.println(i);
		}

	}

}
