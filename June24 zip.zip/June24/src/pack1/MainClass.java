package pack1;

import pack2.AddClass;

public class MainClass {

	public static void main(String[] args) {
		AddClass ob = new AddClass();
		ob.add();

	}

}
