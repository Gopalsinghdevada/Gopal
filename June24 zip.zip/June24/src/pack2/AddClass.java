package pack2;

 public class AddClass {
public  void add() {
    	System.out.println("Add method");
    }
}
