package com.edu.java8.fea;
@FunctionalInterface
interface callInter{
	void mycallMethod(String s);
}

public class MainInterface {

	public static void main(String[] args) {
		//using lambda expression
		callInter mob=(s)-> System.out.println("Hello functional interface "+s);
		
		mob.mycallMethod("Hello");

	}

}
