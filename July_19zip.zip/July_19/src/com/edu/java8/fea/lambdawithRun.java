package com.edu.java8.fea;

public class lambdawithRun {

	public static void main(String[] args) {
	   
		Runnable ob=()->{
			
			System.out.println("Hey buddy Run");
		};
        Thread tob = new Thread(ob);
        tob.start();
	}

}
