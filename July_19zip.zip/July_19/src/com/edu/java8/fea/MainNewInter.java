package com.edu.java8.fea;
//@FunctionalInterface
interface MyNewInterface{
	void display(int i, String s);
	//void method1(String s);
}

public class MainNewInter {

	public static void main(String[] args) {
		MyNewInterface tob1=(i,s)->{System.out.println("Age= "+i+" Name="+s);
		System.out.println("Hello");};
		tob1.display(101, "Gopal");
	}

}
