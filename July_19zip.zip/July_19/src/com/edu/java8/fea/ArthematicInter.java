package com.edu.java8.fea;
@FunctionalInterface
interface addInt{
	int add(int i, int j);
}

@FunctionalInterface
interface subInt{
	int sub(int i, int j);
}


@FunctionalInterface
interface mulInt{
	int mul(int i, int j);
}


public class ArthematicInter {

	public static void main(String[] args) {
		addInt aob=(i,j)->i+j;
		System.out.println("sum ="+aob.add(3, 6));
		
		subInt aob1=(i,j)->i-j;
		System.out.println("sub ="+aob1.sub(3, 6));
		
		mulInt aob2=(i,j)->i*j;
		System.out.println("mul ="+aob2.mul(3, 6));

	}

}
