package com.edu.java8.fea;
@FunctionalInterface
interface retInter1{
	String mycallMethod(String s);
}

public class MainWithREtInter {

	public static void main(String[] args) {
		retInter1 mob=(s)->{
			return "Hello "+s;
		};
        String sob=mob.mycallMethod("Gopal");
         System.out.println(sob);
	}

}
