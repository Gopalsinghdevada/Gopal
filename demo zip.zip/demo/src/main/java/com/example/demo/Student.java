package com.example.demo;

import org.springframework.stereotype.Component;

@Component
public class Student {
    public void display() {
      System.out.println("Student class display method");
    }
}
