package accessp1;

import com.edu.Package2Class;

public class AcccessSpecifierMain extends Package2Class {

	public static void main(String[] args) {
		OtherClassacess ob=new OtherClassacess();
		//within package
		System.out.println("default data "+ob.dfaultval);
		System.out.println("public data "+ob.publicval);
		System.out.println("protected data "+ob.protetedval);
		
		
		//for another package
		AcccessSpecifierMain mob=new AcccessSpecifierMain();
		System.out.println(mob.publicp2val);
		System.out.println(mob.protectedp2val);
		Package2Class pob=new Package2Class();
		System.out.println(pob.publicp2val);
	}

}
