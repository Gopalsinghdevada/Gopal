package com.eduabst;

 abstract class Myabstractclass{// for abstract class object creation is not possible 
      void display() {
    	  System.out.println("Display method");
      }
	 
 }
public class MainAppAbstract extends Myabstractclass {

	public static void main(String[] args) {
	//Myabstractclass ob=new Myabstractclass();
		MainAppAbstract ob=new MainAppAbstract();
		ob.display();
	}

}
