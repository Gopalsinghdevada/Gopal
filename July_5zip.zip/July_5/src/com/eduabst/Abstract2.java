package com.eduabst;
abstract class MyAbstractclass1{
	private int pdata;
	public MyAbstractclass1(int pdata){
		System.out.println(pdata+10);
	}
}

class ChildClass extends MyAbstractclass1{

	public ChildClass(int pdata) {
		super(pdata); //calls super class constructor
		}
}


public class Abstract2 {

	public static void main(String[] args) {
		ChildClass ob=new ChildClass(45);


	}

}
