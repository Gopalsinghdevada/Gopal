package com.edu;

public class Package2Class {

	 private int privatep2val;
	    public int publicp2val;
	    protected int protectedp2val;
	    int defaultp2val;
	   public  Package2Class() {
		   privatep2val=1;
		   publicp2val=2;
		   protectedp2val=3;
		   defaultp2val=4;
	   }
	    

}
