package com.edu.map;

import java.util.Map;
import java.util.TreeMap;

public class TreeMapMainApp {

	public static void main(String[] args) {
		TreeMap<Integer, String> tob=new TreeMap<Integer, String>();
		tob.put(1231,"kausar");
		tob.put(1235,"Divya");
		tob.put(1234,"kiran");
		tob.put(1232,"Gopal");
		System.out.println(tob);
		
		//traversing
		for(Map.Entry<Integer, String> eob:tob.entrySet()) {
			System.out.println(eob.getKey()+"\t" +eob.getValue());
		}
	}

}
