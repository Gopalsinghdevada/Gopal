package com.edu.map;

import java.util.LinkedHashMap;
import java.util.Map;


public class LinkedHashMapMain {

	public static void main(String[] args) {
		LinkedHashMap<Integer, String> lob=new LinkedHashMap<Integer, String>();
		lob.put(1231,"kausar");
		lob.put(1235,"Divya");
		lob.put(1234,"kiran");
		lob.put(1232,"Gopal");
		System.out.println(lob);
		
		//transversing
		for(Map.Entry<Integer, String> eob1:lob.entrySet()) {
			System.out.println(eob1.getKey()+"\t"+eob1.getValue());
		}
			}

}
