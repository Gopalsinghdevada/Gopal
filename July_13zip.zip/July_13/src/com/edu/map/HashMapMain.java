package com.edu.map;

import java.util.HashMap;
import java.util.Map;


public class HashMapMain {

	public static void main(String[] args) {
		HashMap<Integer, String> hob=new HashMap<Integer, String>();
		hob.put(1231,"kausar");
		hob.put(1235,"Divya");
		hob.put(1234,"kiran");
		hob.put(1232,"Gopal");
		System.out.println(hob);
		
		//transversing
		for(Map.Entry<Integer, String> eob2:hob.entrySet()) {
			System.out.println(eob2.getKey()+"\t"+eob2.getValue());
		}

	}

}
