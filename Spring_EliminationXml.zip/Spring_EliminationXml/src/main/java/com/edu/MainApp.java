package com.edu;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainApp {

	public static void main(String[] args) {
		ApplicationContext ctx=new AnnotationConfigApplicationContext(MyConfig.class);
		  //College cob=ctx.getBean(College.class);
		
		
		College cob=(College) ctx.getBean("collegeBean",College.class);//College collegeBean=new College();
		              cob.display();
		              System.out.println("object of college class "+cob);

	}

}
