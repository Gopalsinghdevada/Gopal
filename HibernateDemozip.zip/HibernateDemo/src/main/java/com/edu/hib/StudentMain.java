package com.edu.hib;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

public class StudentMain {

	public static void main(String[] args) {
		Configuration config=new Configuration().configure().addAnnotatedClass(Student.class);
        ServiceRegistry reg=new ServiceRegistryBuilder().applySettings(config.getProperties()).buildServiceRegistry();
        SessionFactory sf=config.buildSessionFactory(reg);
        Session session=sf.openSession();
        Transaction tx=session.beginTransaction();
        
        Student sob=new Student();
      /*  sob.setSid(8);
        sob.setSanme("Nhedha");
         //insert into student(sid, sname) values(1,'kiran')
        
       
       
       sob.setSanme("swetha");
       session.save(sob);
       
       tx.commit();
       session.evict(sob);
       sob.setSanme("Ravi");
        sob.setSid(8);
      // sob.setSanme("vikram");
      //  session.save(sob);
        session.delete(sob);
        tx.commit();
        Student ob1=(Student) session.get(Student.class, 1);//select * from student
        System.out.println("Name = "+ob1.getSanme());*/
        //all the records
        Query q=session.createQuery("from Student");//return all the records 
        List l=q.list();
        
        //iterator arraylist
        Iterator<Student> lst=l.iterator();
        while(lst.hasNext()) {
        	Student s=lst.next();
        	System.out.println(s.getSid()+" "+s.getSanme() );
        }
        
 
      
	}

}
