package com.variables;

public class AddTwoNumbers {
	 public static void main(String[] args) {
		 int num1,num2,sum,sub,pro,div,mod;
		 num1=19;
		 num2=56;
		 //find sum
		 sum=num1+num2;
		 System.out.println("THE ADDITON IS="+sum);
		 
		 sub=num2-num1;
		 System.out.println("THE SUBSTRACTION IS="+sub);
		 
		 pro=num1*num2;
		 System.out.println("THE PRODUCT IS="+pro);
		 
		 div=num2/num1;
		 System.out.println("THE DIVISION IS="+div);
		 
		 mod=num2%num1;
		 System.out.println("THE REMINDER IS="+mod);
		 
	}

}
