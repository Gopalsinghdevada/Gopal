package com.variables;

public class AreaOfCircle {

	public static void main(String[] args) {
	double r=2;
		double area=3.14*r*r;
		System.out.println("THE AREA OF CIRCLE IS="+area);

	}

}
