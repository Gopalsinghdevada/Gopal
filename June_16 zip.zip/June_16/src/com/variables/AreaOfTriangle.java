package com.variables;

public class AreaOfTriangle {

	public static void main(String[] args) {
		double l=30.5;
		int h=5;
		double b=6.3;
		double area=(l*h)/2f;
		double rectarea=(l*b);
		System.out.println("AREA OF TRIANGLE IS="+area);
		System.out.println("AREA OF RECTANGLE IS="+rectarea);

	}

}
