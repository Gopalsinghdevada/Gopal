package com.variables;


public class VariableDatatypes {

	public static void main(String[] args) {
		int num; //declaration
		num=10;  //static initialization
		float vfal=98.78f;
		double dval=87.45;
		char ch='A';
		String s="Gopal";
		System.out.println("number is num:"+num);
		System.out.println("float value is:"+vfal);
		System.out.println("double value is:"+dval);
		System.out.println("character is:"+ch);
		System.out.println("string is:"+s);
	}

}
