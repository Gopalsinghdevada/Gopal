package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeRestApi1Application {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeRestApi1Application.class, args);
	}

}
