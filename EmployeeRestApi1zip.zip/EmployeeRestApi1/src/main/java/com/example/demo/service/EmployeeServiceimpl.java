package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Employee;
import com.example.demo.error.EmployeeNotFoundException;
import com.example.demo.repository.EmployeeRepository;

@Service
public class EmployeeServiceimpl implements EmployeeService{

	@Autowired
	private EmployeeRepository employeeRepository;
	@Override
	public Employee employeeSave(Employee employee) {
		
		return employeeRepository.save(employee);
	}
	@Override
	public List<Employee> getAllEmployee() {
		
		return employeeRepository.findAll();
	}
	@Override
	public Employee findEmployeeById(Long eid) throws EmployeeNotFoundException {
		
		Optional<Employee> employee=employeeRepository.findById(eid);
            if(!employee.isPresent())
            	throw new EmployeeNotFoundException("Employee id is not present to find");
            return employee.get();
	}
	@Override
	public void deleteEmployeeById(Long eid) throws EmployeeNotFoundException {
		Optional<Employee> employee=employeeRepository.findById(eid);
		if(!employee.isPresent())
			throw new EmployeeNotFoundException("Employee id is not present for deletion");
		employeeRepository.deleteById(eid);
		
	}
	@Override
	public Employee updateEmployeeById(Long eid, Employee employee) throws EmployeeNotFoundException {
		Optional<Employee> eob=employeeRepository.findById(eid);
		if(!eob.isPresent())
			throw new EmployeeNotFoundException("Employee id is not present for updation");
		else {
			Employee eob1=employeeRepository.findById(eid).get();
			if(employee.getEmployeeName() != null)
				eob1.setEmployeeName(employee.getEmployeeName());
			if(employee.getEmployeeDept() != null)
				eob1.setEmployeeDept(employee.getEmployeeDept());
			if(employee.getEmployeeSalary() != 0)
				eob1.setEmployeeSalary(employee.getEmployeeSalary());
			return employeeRepository.save(eob1);
		}
		
	}
	@Override
	public Employee findEmployeeByName(String ename) {
		
		return employeeRepository.findByEmployeeName(ename);
	}
	@Override
	public Employee findEmployeeByDepartment(String edept) {
		
		return employeeRepository.findByEmployeeDept(edept);
	}

}
