package com.example.demo.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

@	Entity
public class User {
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer userId;
@NotEmpty(message = "Username should not be empty")
@Size(min=3, max=30, message="Name should be min 3 char and max 30 char")
	private String userName;
@NotEmpty(message = "Email id should not be empty ")
@Email(message = "Invalid email id")
	private String userEmail;
@NotEmpty(message = "Password should not be empty")
@Size(min=3, max=30, message = "Password should be min 3 char and max 30 char ")
	private String userPassword;
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	public String getUserPassword() {
		return userPassword;
	}
	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}
	
}
