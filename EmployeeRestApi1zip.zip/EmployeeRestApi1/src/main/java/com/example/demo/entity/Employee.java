package com.example.demo.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

@Entity
public class Employee {
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)

    private Long employeeId;
@NotEmpty(message="Employee name should not be empty")
@Size(min=3, max=30, message="Employee name size should be min 3 char and max 30")
	private String employeeName;
@NotEmpty(message="Employee department should not be empty")
@Size(min=3, max=30, message="Employee department size should be min 3 char and max 30")
	private String employeeDept;
//@NotEmpty(message="Employee salary should not be empty")
//@Size(min=3, max=7, message="Employee salary size should be min 3 number and max 7")
@Min(value=10000,message="Salary should not be less than 10000")	
private float employeeSalary;
	public Long getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(Long employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public String getEmployeeDept() {
		return employeeDept;
	}
	public void setEmployeeDept(String employeeDept) {
		this.employeeDept = employeeDept;
	}
	public float getEmployeeSalary() {
		return employeeSalary;
	}
	public void setEmployeeSalary(float employeeSalary) {
		this.employeeSalary = employeeSalary;
	}
	
	
}
