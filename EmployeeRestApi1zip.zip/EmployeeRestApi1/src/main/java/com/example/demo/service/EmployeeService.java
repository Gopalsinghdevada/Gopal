package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Employee;
import com.example.demo.error.EmployeeNotFoundException;

public interface EmployeeService {

	List<Employee> getAllEmployee();

	Employee employeeSave(Employee employee);

	Employee findEmployeeById(Long eid) throws EmployeeNotFoundException;

	void deleteEmployeeById(Long eid) throws EmployeeNotFoundException;

	Employee updateEmployeeById(Long eid, Employee employee) throws EmployeeNotFoundException;

	Employee findEmployeeByName(String ename);

	Employee findEmployeeByDepartment(String edept);

}
