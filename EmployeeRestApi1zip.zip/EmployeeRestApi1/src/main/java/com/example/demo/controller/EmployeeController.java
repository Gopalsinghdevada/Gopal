package com.example.demo.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Employee;
import com.example.demo.error.EmployeeNotFoundException;
import com.example.demo.service.EmployeeService;

@RestController
public class EmployeeController {

	@Autowired 
	private EmployeeService employeeservice;
	//insert records
	@PostMapping("/addemployee")
	public ResponseEntity<Employee> employeeSave(@Valid @RequestBody Employee employee) {
		Employee saveemployee=employeeservice.employeeSave(employee);
		System.out.println("Employee save");
		return new ResponseEntity<Employee>(saveemployee, HttpStatus.CREATED);
		
	}
	//fetch records
	@GetMapping("getallemployee")
	public List<Employee> getAllEmployee(){
		return employeeservice.getAllEmployee();
		
	}
	//find record based on id
	@GetMapping("getemployeebyid/{eid}")
	public Employee findEmployeeById(@PathVariable("eid") Long eid) throws EmployeeNotFoundException {
		return employeeservice.findEmployeeById(eid);
		
	}
	//delete record based on id
	@DeleteMapping("deleteemployeebyid/{eid}")
	public String deleteEmployeeById(@PathVariable("eid") Long eid) throws EmployeeNotFoundException {
		employeeservice.deleteEmployeeById(eid);
		return "Record deleted successfully";
	}
	//update data using id
	@PutMapping("updateemployeebyid/{eid}")
	public Employee updateEmployeeById(@PathVariable("eid") Long eid, @RequestBody Employee employee) throws EmployeeNotFoundException {
		return employeeservice.updateEmployeeById(eid, employee);
	}
	//find by name
	@GetMapping("getemployeebyname/{ename}")
	public Employee findEmployeeByName(@PathVariable("ename") String ename) {
		return employeeservice.findEmployeeByName(ename);
	}
	//find by department
	@GetMapping("getemployeebydepartment/{edept}")
	public Employee findEmployeeByDepartment(@PathVariable("edept") String edept) {
		return employeeservice.findEmployeeByDepartment(edept);
	}
}
