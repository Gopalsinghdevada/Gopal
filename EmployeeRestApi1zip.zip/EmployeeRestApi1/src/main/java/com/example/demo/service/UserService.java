package com.example.demo.service;

import javax.validation.Valid;

import com.example.demo.entity.User;

public interface UserService {

	User createUser(User user);

}
