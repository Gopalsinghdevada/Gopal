package com.edustr;

public class SubString2 {

	public static void main(String[] args) {
		String s="Hello world";
		
		System.out.println(s.substring(1));
		System.out.println(s.substring(1, 7));
		
		String s1="Mahathma karamachand Gandhi";
		System.out.print(s1.charAt(0)+".");
		System.out.print(s1.charAt(s1.indexOf(' ')+1)+".");
		int b2=s1.lastIndexOf(' ')+1;
		System.out.println(s1.substring(b2));
		System.out.println(s1.startsWith("Mahathma"));
        System.out.println(s1.endsWith("Gandhi"));
        s1.spl
	}

}
