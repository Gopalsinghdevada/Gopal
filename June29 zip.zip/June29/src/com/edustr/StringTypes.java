package com.edustr;

public class StringTypes {

	public static void main(String[] args) {
		String s="Hello";
		String s1="Hello";

		String s2=new String("Hello");
		String s3=new String("Hello");
		
		if(s==s1) { // compare address.
			System.out.println("s and s1 has same address");
		}else {
			System.out.println("s and s1 has different same address");
		}

		if(s1.equals(s2)) { //compare content
			System.out.println("s1 and s2 has same info");
		}else
		{
			System.out.println("s1 and s2 has no same info");
		}
		if(s2==s3) {//compare the address
			System.out.println("s2 and s3 has same address");
		}else {
			System.out.println("s2 and s3 dont has same address");
		}
		
		if(s2.equals(s3)) { //compare the contents
			System.out.println("s2 and s3 have same info");
		}else {
			System.out.println("s2 and s3 have different info");
		}



	}

}
