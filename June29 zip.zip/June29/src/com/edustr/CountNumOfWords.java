package com.edustr;

public class CountNumOfWords {

	public static void main(String[] args) {
		 int b=0;
			String s="hello world gopal singh";
			int count=1;
			for(int i=0;i<s.length();i++) {
				if(s.charAt(i)==' ') {
				count++;
			}
			}
			b=s.length()-count;
			System.out.println(count);

	}

}
