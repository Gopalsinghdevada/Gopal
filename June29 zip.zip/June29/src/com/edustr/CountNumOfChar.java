package com.edustr;

public class CountNumOfChar {// excluding blank

	public static void main(String[] args) {
        int b=0;
		String s="hello world";
		int count=0;
		for(int i=0;i<s.length();i++) {
			if(s.charAt(i)==' ') {
			count++;
		}
		}
		b=s.length()-count;
		System.out.println(b);
		
	}

}
