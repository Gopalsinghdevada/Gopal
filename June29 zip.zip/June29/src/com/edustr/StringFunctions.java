package com.edustr;

public class StringFunctions {

	public static void main(String[] args) {
		//index give position from l to r
		//lastindex gives from r to l
		String s="hello";
		
		System.out.println("index of l: "+s.indexOf('l'));
		System.out.println("lastindex of l: "+s.lastIndexOf('l'));
	}

}
