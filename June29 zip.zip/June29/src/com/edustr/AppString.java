//to count number of vowels 
package com.edustr;

public class AppString {

	public static void main(String[] args) {
		int vc=0;
		String s="Hello world";
		int l=s.length();
		System.out.println("No of chars="+l);
		for(int i=0;i<l;i++) {
			char ch=s.toLowerCase().charAt(i);
			if(ch=='a' || ch=='e' || ch=='i' || ch=='o' || ch=='u') {
				vc++;
			}
			
		}
		System.out.println("No of vowels are: "+vc);
	}

}
