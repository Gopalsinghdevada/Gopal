package com.edustr;

import java.util.Scanner;

public class ValidateUserNp {

	public static void main(String[] args) {
        String user, pass;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the user name");
        user=sc.nextLine();
        System.out.println("Enter the password");
        pass = sc.nextLine();
        if(user.equalsIgnoreCase("admin") && pass.equals("admin123")) {
        	System.out.println("User valid");
        }else
        	System.out.println("Invalid user");

	}

}
