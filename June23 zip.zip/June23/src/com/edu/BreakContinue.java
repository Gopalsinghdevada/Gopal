package com.edu;

import java.util.Scanner;

public class BreakContinue {

	public static void main(String[] args) {
              Scanner sc=new Scanner(System.in);
              int num,fact=1;
              System.out.println("Enter number to find factorial");
              num=sc.nextInt();
              
           /*   for(int i=num;i>=1;i--) {
            	  fact = fact * i;
              }
              System.out.println("Factorial of "+num+" is "+fact);
*/
              int i;
              i=num;
              while(i>=1) {
            	  fact = fact*i;
            	i--;
              }
              System.out.println("Factorial of "+num+" is "+fact);
	}

}
