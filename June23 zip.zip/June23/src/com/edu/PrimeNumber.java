package com.edu;

import java.util.Scanner;

public class PrimeNumber {

	public static void main(String[] args) {
		 Scanner sc=new Scanner(System.in);
         int num,c=0;
         System.out.println("Enter number to find factors of");
         num=sc.nextInt();
          
         
         for(int i=1;i<=num;i++) {
        	 if(num%i==0) {
        		 c++;
        	  }
         } if(c==2){
        	 System.out.println(num+" is a prime");
         }else{
        	 System.out.println(num+" is not a prime");
         }
        	 
        
        	 
	}

}
