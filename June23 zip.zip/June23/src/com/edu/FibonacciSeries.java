package com.edu;

import java.util.Scanner;

public class FibonacciSeries {

	public static void main(String[] args) {
		 Scanner sc=new Scanner(System.in);
         int num,first,second,third;
         first=0;
         second=1;
        System.out.println("Enter number terms");
         num=sc.nextInt();
         System.out.println("Series is");
         for(int i=3;i<=num;i++) {
        	 System.out.print(" "+first);
        	 third=first+second;
        	 first=second;
        	 second=third;
        	 
        	
         }
          
	}

}
