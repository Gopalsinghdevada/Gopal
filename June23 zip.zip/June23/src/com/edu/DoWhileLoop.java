package com.edu;

public class DoWhileLoop {

	public static void main(String[] args) {
		int i=1;
		while(i<1) {
			System.out.println(i);
		}

		do {
			System.out.println(i); 
		}while(i<1);
	}

}
