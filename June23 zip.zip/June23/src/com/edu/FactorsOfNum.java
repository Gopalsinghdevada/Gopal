package com.edu;

import java.util.Scanner;

public class FactorsOfNum {

	public static void main(String[] args) {
		 Scanner sc=new Scanner(System.in);
         int num;
         System.out.println("Enter number to find factors of");
         num=sc.nextInt();
         
         for(int i=1;i<=num;i++) {
        	 if(num%i==0) {
        		 System.out.println(""+i);
        	 }
        	 else {
        		 continue;
        	 }
         }

	}

}
