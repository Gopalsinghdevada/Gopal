package com.june18;

import java.util.Scanner;

public class ElectricityBill {

	public static void main(String[] args) {
		int units;
		double billamount;
		String name;
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter units");
		units = sc.nextInt();
		System.out.println("Enter Customer name");
        name = sc.next();
		
        if(units <= 0) {
            System.out.println(name+ " Number of units should not be zero or negative");
            System.exit(0);
        }
        
        if(units >= 1 && units <= 100) {
			billamount = units*2;
		}
		else if(units >= 101 && units <= 300){
			billamount = 100*2 + (units - 100)*3;
		}else {
			billamount = 100*2 + (units - 100)*3 + (units -300)*5;
			
			billamount = billamount + (0.025)*billamount;
		}
		System.out.println("Customer is "+name);
		System.out.println("Electricity units are "+units);
		System.out.println("Bill Amount is "+billamount);

	}

}
