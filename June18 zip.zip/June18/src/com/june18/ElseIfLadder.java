//program to find largest of 3 numbers using else if ladder
package com.june18;

import java.util.Scanner;

public class ElseIfLadder {

	public static void main(String[] args) {
	  
		int marks;
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter marks");
		marks = sc.nextInt();
		
		if(marks >= 80 &&  marks <= 100 ) {
			System.out.println("Passed with GRADE A");
		}else if(marks >= 60 &&  marks <= 79) {
			System.out.println("Passed with GRADE B");
		}else if(marks >= 35 &&  marks <= 59) {
			System.out.println("Passed with GRADE C");
		}else if(marks >= 0 &&  marks <= 34) {
			System.out.println("FAIL");
		}else
		{
			System.out.println("Invalid marks");
		}
				

	}

}
