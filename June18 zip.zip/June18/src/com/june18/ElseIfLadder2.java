package com.june18;

import java.util.Scanner;

public class ElseIfLadder2 {

	public static void main(String[] args) {
	
		char g;
Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Grade");
		 g = sc.next().charAt(0);
		 
		 if(g=='A' || g=='a') {
			 System.out.println("Marks are in range 80-100");
		 }else if(g=='B' || g=='b') {
			 System.out.println("Marks are in range 60-79");
		 }else if(g=='C' || g=='c') {
			 System.out.println("Marks are in range 35-59");
		 }else if(g=='F' || g=='c') {
			 System.out.println("Marks are in range 0-34");
		 }else {
			 System.out.println("Marks are Invalid");
		 }

	}

}
