package pom.xml;

import static org.junit.Assert.*;

import org.junit.Test;

public class EmployeeTestCase {

	@Test
	public void test() {
		String name="edubridge";
		assertEquals(name,"edubridge");
	}
	@Test
	public void add() {
		int s,a,b;
		a=10;b=20;
		s=a+b;
		assertEquals(s, 30);
	}
	@Test
	public void sub() {
		int a,b,s;
		a=10;b=20;
		s=b-a;
		assertEquals(s,10);
	}
	@Test
	public void mul() {
		int a,b,s;
		a=10;b=20;
		s=a*b;
		assertEquals(s, 200);
	}
	@Test
	public void Strings() {
		String name="Hello";
		assertEquals(name, "Hello");
	}

}
