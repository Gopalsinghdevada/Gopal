package com.edu.hib;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

public class EmployeeMain {

	public static void main(String[] args) {
		Configuration config=new Configuration().configure().addAnnotatedClass(Employee.class);
		ServiceRegistry reg=new ServiceRegistryBuilder().applySettings(config.getProperties()).buildServiceRegistry();
		SessionFactory sf=config.buildSessionFactory(reg);
		Session session =sf.openSession();
		Transaction tx=session.beginTransaction();
		
		Employee eob=new Employee();
		/*eob.setEid(1);
		eob.setEname("Rajendra");
		eob.setEage(22);
		eob.setEsalary(3300.00f);
		session.save(eob);
		tx.commit();*/
		//update record change name
		
		Query q=session.createQuery("update Employee set ename=:n where eid=:1");
		q.setParameter("n", "Poonam");
		q.setParameter("i", 1);
		int i=q.executeUpdate();
		if(i>0) {
			System.out.println("Record is updated");
		}else {
			System.out.println("not updated");
		}
		session.save(eob);
		tx.commit();

	}

}
