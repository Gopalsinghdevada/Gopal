package com.edu;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class DeleteServlet
 */
@WebServlet("/DeleteServlet")
public class DeleteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
      private Connection conn;
      private PreparedStatement pst;
      private ResultSet rs;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeleteServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		PrintWriter out=response.getWriter();
		String em=request.getParameter("semail");
		try {
			conn=DatabaseConnect.getConnection();
			String s="Select * from student where emailid=?";
			pst=conn.prepareStatement(s);
			pst.setString(1, em);
			rs=pst.executeQuery();
			if(rs.next()) {
				String del="delete from student where emailid=?";
				pst=conn.prepareStatement(del);
				pst.setString(1, em);
				int rv=pst.executeUpdate();
				if(rv>0) {
					out.println("Student is Deleted!!!!");
				}else {
					out.println("Error while deleting");
				}
				
			}else {
				out.println("Email id not exists");
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}

}
