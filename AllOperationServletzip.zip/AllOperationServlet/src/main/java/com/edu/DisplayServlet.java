package com.edu;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class DisplayServlet
 */
@WebServlet("/DisplayServlet")
public class DisplayServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       private Connection conn;
       private PreparedStatement pst;
       private ResultSet rs;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DisplayServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		PrintWriter out=response.getWriter();
		try {
		conn=DatabaseConnect.getConnection();
		response.setContentType("text/html");
		 String s="select * from student";
	     pst=conn.prepareStatement(s);
	     rs=pst.executeQuery();
	     out.println("<html><body>");
	     out.println("<table border='2'><tr><th>name</th><th>password</th><th>emailid</th><th>age</th></tr>");
	     while(rs.next()) {
	    	 String sn=rs.getString("name");
	    	 String sp=rs.getString("password");
	    	 String em=rs.getString("emailid");
	    	 int ag=rs.getInt("age");
	    	 out.println("<tr><td>"+sn+"</td>"+"<td>"+sp+"</td>"+"<td>"+em+"</td>"+"<td>"+ag+"</td></tr>");
	     }
	     out.println("</table>");
	     out.println("</body></html>");
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	}


