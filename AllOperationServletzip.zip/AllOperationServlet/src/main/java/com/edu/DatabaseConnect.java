package com.edu;

import java.sql.Connection;
import java.sql.DriverManager;

public class DatabaseConnect {
     public static Connection conn;
     public static String driver="com.mysql.cj.jdbc.Driver";
     public static String url="jdbc:mysql://localhost:3306/registerservlet";
     public static String un="root";
     public static String up="root";
     public static Connection getConnection() {
    	 try {
    		 Class.forName(driver);
    		 conn=DriverManager.getConnection(url,un,up);
    		 if(conn==null) {
    			 System.out.println("Database connection error");
    		 }
    		 
    	 }catch(Exception e) {
    		 e.printStackTrace();
    	 }
    	 return conn;
     }

}
