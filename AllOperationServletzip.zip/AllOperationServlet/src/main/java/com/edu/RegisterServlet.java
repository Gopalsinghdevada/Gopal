package com.edu;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class RegisterServlet
 */
@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public Connection conn;  
    PreparedStatement pst;
    ResultSet rs;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	conn=DatabaseConnect.getConnection();
	System.out.println("check connection "+conn);
	String n=request.getParameter("sname");
	String p=request.getParameter("spass");
	String em=request.getParameter("semail");
	int age=Integer.parseInt(request.getParameter("sage"));
	PrintWriter out=response.getWriter();
	try {
		//check if emailid exists if not then go for insert
		String sel="select * from student where emailid=?";
    	pst=conn.prepareStatement(sel);
    	pst.setString(1, em);
        rs = pst.executeQuery();
        if(!rs.next()) {
	String stmt="insert into student values(?, ?, ?, ?)";
	
		pst=conn.prepareStatement(stmt);
		pst.setString(1, n);
		pst.setString(2, p);
		pst.setString(3, em);
		pst.setInt(4, age);
		
		int rv=pst.executeUpdate();
		if(rv>0) {
		   out.println("Registered successfully");
		}
	}else {
		out.println("Emailid already exists");
	}
   } catch (SQLException e) {

		e.printStackTrace();
	}
	
	
	}

}
