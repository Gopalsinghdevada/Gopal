package com.edu;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class UpdateServlet
 */
@WebServlet("/UpdateServlet")
public class UpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Connection conn;  
    private PreparedStatement pst; 
    private ResultSet rs;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		PrintWriter out=response.getWriter();
		System.out.println("check connection "+conn);
		
		//get data from html is same as like reading data using scanner in core java
		String em=request.getParameter("semail");
		String n=request.getParameter("sname");
		
		//for update check email id exists
		
		try {
			conn=DatabaseConnect.getConnection();
				String sel="select * from student where emailid=?";
				pst=conn.prepareStatement(sel);
				pst.setString(1, em);
				rs=pst.executeQuery();
				if(rs.next()) {// if email id exists then go for update
				String stmt="update student set name=? where emailid=?";
				pst=conn.prepareStatement(stmt);
				pst.setString(1, n);
				pst.setString(2, em);
				int rv=pst.executeUpdate();
				if(rv>0) {
				   out.println("updated successfully");
				}else {
					out.println("Error in changing");
				}
				}
				else{
					out.println("Email id does not exists");
					} 
				
				
			}catch (SQLException e) {
				e.printStackTrace();
			}
	}

}
