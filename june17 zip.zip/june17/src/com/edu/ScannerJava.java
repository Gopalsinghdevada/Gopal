package com.edu;
import java.util.Scanner;
public class ScannerJava {

	public static void main(String[] args) {
		String name;
		int age;
		float fees;
		double amount;
		char gender;
		
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter name");
		name=sc.nextLine();
		System.out.println("Enter age");
		age=sc.nextInt();
		System.out.println("Enter fees");
		fees=sc.nextFloat();
		System.out.println("Enter amount");
		amount=sc.nextDouble();
		System.out.println("Enter gender m/f");
		gender=sc.next().charAt(0);
		
		System.out.println("Your Details are");
		System.out.println("Name "+name);
		System.out.println("AGE "+age);
		System.out.println("FEES "+fees);
		System.out.println("AMOUNT "+amount);
		System.out.println("GENDER "+gender);


	}

}
