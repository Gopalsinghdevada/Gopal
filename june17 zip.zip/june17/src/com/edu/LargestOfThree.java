package com.edu;

import java.util.Scanner;

public class LargestOfThree {

	public static void main(String[] args) {
		int first, second,third,large;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter three numbers ");
	      first=sc.nextInt();
	      second=sc.nextInt();
	      third=sc.nextInt();
	      
	    //ternary operator is replacement of if else
	     // large=(first>=second && first>=third)?first:(second>=first && second>=third)?second:third;
	   //   System.out.println("Largest of "+first+" and "+second+" and "+third+" is "+large);

	      if(first >= second && first >= third) {
	    	  System.out.println("Largest of "+first+" and "+second+"  and "+third+" is "+first);
	      }else if(second >= first && second >= third) {
	    	  System.out.println("Largest of "+first+" and "+second+" and  "+third+" is "+second);
	      }else {
	    	  System.out.println("Largest of "+first+" and "+second+" and  "+third+" is "+third);
	      }
	}

}
