package com.edu;

import java.util.Scanner;

public class VowelsConsonate {

	public static void main(String[] args) {
		  char ch;
		 Scanner sc = new Scanner(System.in);
		 System.out.println("Enter character");
		 ch=sc.next().charAt(0);
		 System.out.println("Character is:"+ch);
		 
		 if(ch=='a' || ch=='e' || ch=='i' || ch=='o' || ch=='u') {
		 
			 System.out.println("Char is a vowels");
		 }else {
			 System.out.println("Char is a consoant");
		 }
	}

}
