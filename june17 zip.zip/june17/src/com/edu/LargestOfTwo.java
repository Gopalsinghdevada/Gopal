//ternary operator is replacement of if else
package com.edu;

import java.util.Scanner;

public class LargestOfTwo {

	public static void main(String[] args) {
		int first, second,large;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Two numbers ");
	      first=sc.nextInt();
	      second=sc.nextInt();
	      
	     // large=(first>second)?first:second;
	     // System.out.println("Largest of"+first+" and "+second+" is"+large);
	      
	      //or use if else
	      
	      if(first > second) {
	    	  System.out.println("Largest of "+first+" and "+second+" is  "+first);
	      }else {
	    	  System.out.println("Largest of "+first+" and "+second+" is  "+second);
	      }

	}

}
