package com.edu;

import java.util.Scanner;

public class LargestOfFour {

	public static void main(String[] args) {
		int first, second,third,fourth,large;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter four numbers ");
	      first=sc.nextInt();
	      second=sc.nextInt();
	      third=sc.nextInt();
	      fourth=sc.nextInt();
	      
	    //ternary operator is replacement of if else
	    //  large=(first>second && first>third && first>fourth)?first:(second>first && second>third && second>fourth)?second:(third>first && third>second && third>fourth)?third:fourth;
	    // System.out.println("Largest of "+first+" , "+second+" , "+third+" , "+fourth+" is "+large);

	      if(first >= second && first >= third && first >= fourth) {
	    	  System.out.println("Largest of "+first+" , "+second+"  , "+third+" and "+fourth+" is "+first);
	      }else if(second >= first && second >= third && second >= fourth) {
	    	  System.out.println("Largest of "+first+" , "+second+" ,  "+third+" and "+fourth+" is "+second);
	      }else if(third >= first && third >= second && third >= fourth){
	    	  System.out.println("Largest of "+first+" , "+second+" ,  "+third+" and "+fourth+" is "+third);
	      }else {
	    	  System.out.println("Largest of "+first+" , "+second+" ,  "+third+" and "+fourth+" is "+fourth);
	      }

	}

}
