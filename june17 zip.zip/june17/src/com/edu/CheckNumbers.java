package com.edu;

import java.util.Scanner;

public class CheckNumbers {

	public static void main(String[] args) {
		//Program to find number is even or odd
		int num;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter num ");
		num=sc.nextInt();
		
		if(num==0) {
			System.out.println("Number is positive");
		}
		if(num>=0) {
			System.out.println("Number is positive");
		}
		if(num<0) {
			System.out.println("Number is negative");
		}

	}

}
