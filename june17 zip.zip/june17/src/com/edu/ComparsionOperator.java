package com.edu;

public class ComparsionOperator {

	public static void main(String[] args) {
      int a=8;
      int b=7;
      boolean c=(a>b);
      System.out.println("c is="+c);
    		  

	}

}
