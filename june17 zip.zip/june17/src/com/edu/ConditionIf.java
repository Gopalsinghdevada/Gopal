package com.edu;

import java.util.Scanner;

public class ConditionIf {

	public static void main(String[] args) {
		String name;
		int age;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter any name");
		name=sc.nextLine();
		System.out.println("Enter AGE ");
		age=sc.nextInt();
		
		if(age>=18) {
			System.out.println("Eligible for vote ");
		}else {
			System.out.println("Not eligible for vote");
		}
		
	}

}
