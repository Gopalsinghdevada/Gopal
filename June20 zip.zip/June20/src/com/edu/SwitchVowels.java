package com.edu;

import java.util.Scanner;

public class SwitchVowels {

	public static void main(String[] args) {
		char ch;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a charcter");
		ch=sc.next().toLowerCase().charAt(0);
		
		switch(ch){
		
		case 'a':System.out.println("Is a Vowel");
		         break;
		case 'e':System.out.println("Is a Vowel");
	             break;
		case 'i':System.out.println("Is a Vowel");
	             break;
		case 'o':System.out.println("Is a Vowel");
	             break;
		case 'u':System.out.println("Is a Vowel");
	             break;
		
	    default:System.out.println("Invalid input");     
		}

	}

}
