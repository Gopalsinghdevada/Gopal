package com.edu;

import java.util.Scanner;

class Area1{
	int squareArea(int side) {
	   return side*side;
	}
	void rectangleArea(int l,int b) {
		System.out.println("Area of rectangle is "+(l*b));
	}
	void triangleArea() {
		Scanner sc1 = new Scanner(System.in);
		System.out.println("Enter base and height of triangle");
		int base=sc1.nextInt();
		int height=sc1.nextInt();
		float atr=(base*height)*0.5f;
		System.out.println("Area of triangle is "+atr);
	}
	public float circleArea() {
		Scanner sc1 = new Scanner(System.in);
		System.out.println("Enter radius of a circle:");
		float radius = sc1.nextFloat();
		return (3.14159f*radius*radius);
	}
}
public class MenuDriven2 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		Area aob1 = new Area();
		while(true) {
		System.out.println("Enter your choice");
		System.out.println("1.Calculate area of square");
		System.out.println("2.Calculate Area of Reactangle");
		System.out.println("3.Calculate area of triangle");
		System.out.println("4.CalculateArea of Circle");
		
		int choice=sc.nextInt();
		switch(choice) {
		case 1:System.out.println("Enter the side of square");
		       int side=sc.nextInt();
		       int a=aob1.squareArea(side);
		       System.out.println("Area of a Square is:"+a);
		       break;
		case 2:System.out.println("Enter the length and breadth of rectangle");
	           int l=sc.nextInt();
	           int b=sc.nextInt();
	           aob1.reactangleArea(l, b);
	           break;
		case 3:aob1.triangleArea();
		       break;
		case 4:float a1 = aob1.circleArea();
		       System.out.println("Area of circle is: "+a1);
		       break;
	    default:System.out.println("Invalid input");
		}
		System.out.println("Do you want to stop press n else any other char to continue");
		char ch=sc.next().charAt(0);
		if(ch=='n') {
			
			break;
		}
		System.out.println("program is terminated");
	}
	}
}
