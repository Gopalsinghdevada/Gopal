package com.edu;

import java.util.Scanner;

class Student {
	int id;
	String name;
	float feespending;
	
	void inputData() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter id of a Student");
		id=sc.nextInt();
		System.out.println("Enter name of a Student");
		name=sc.next();
		System.out.println("Enter feespending of a Student");
		feespending=sc.nextFloat();
	}
	void Display() {
		System.out.println(" id of a Student is "+id);
		System.out.println(" name of a Student "+name);
		System.out.println(" feespending of a Student "+feespending);
	}
}

public class StudentDetails {

	public static void main(String[] args) {
		Student s1 = new Student();
		s1.inputData();
		s1.Display();
		
		Student s2 = new Student();
		s2.inputData();
		s2.Display();

		Student s3 = new Student();
		s3.inputData();
		s3.Display();

	}

}
