package com.edu;

import java.util.Scanner;

public class SwitchCase2 {

	public static void main(String[] args) {
		String day;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the day");
		day=sc.next();
		
		switch(day){
		
		case "SUNDAY":System.out.println("Day one");
		       break;
		case "MONDAY":System.out.println("Day two");
	           break;
		case "TUESDAY":System.out.println("Day three");
	           break;
		case "WEDNESDAY":System.out.println("Day four");
	           break;
		case "THURSDAY":System.out.println("Day five");
	           break;
		case "FRIDAY":System.out.println("Day six");
	           break;
		case "SATURDAY":System.out.println("Day seven");
	           break;
	           
	    default:System.out.println("Invalid input");     
		}

	}

}
