package com.edu;

import java.util.Scanner;

public class EvenOddSwitch {

	public static void main(String[] args) {
		int num;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter number");
		num=sc.nextInt();
		
		switch(num%2) {
		
		case 0:System.out.println("Number is Even");
		       break;
		case 1:System.out.println("Number is odd");
		       break;
		default:System.out.println("Invalid input");
		}

	}

}
