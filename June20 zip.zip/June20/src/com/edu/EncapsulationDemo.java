package com.edu;

import java.util.Scanner;

class Circle{   //blue print
	 float radius;  //state of a classor instance variable of a class or member data
     float area;
	
 void inputData() {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the radius");
		radius = sc.nextInt();
	}
	
	//calculate the area
	 void calculateArea() {
		float pi=3.14159f;
		area=pi*radius*radius;
	}
	
	void displayArea() {
		System.out.println("Area of cicle of radius "+radius+" is"+area);
	}
	
}



public class EncapsulationDemo {

	public static void main(String[] args) {
		//create an object
		
				Circle aob = new Circle();// its a realtime entity
				Circle aob1 = new Circle();
				Circle aob2= new Circle();
				
				aob.inputData();
				aob.calculateArea();
				aob.displayArea();
				
				aob1.inputData();
		        aob1.calculateArea();
				aob1.displayArea();
				
				
				aob2.inputData();
				aob2.calculateArea();
				aob2.displayArea();
				
			}

		

	}


