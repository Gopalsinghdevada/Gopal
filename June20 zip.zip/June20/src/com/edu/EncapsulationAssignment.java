package com.edu;
import java.util.Scanner;

class AreaCircle1{
    float a;
    float r;
    
    void inputData() {
    	Scanner sc = new Scanner(System.in);
    	System.out.println("Enter radius");
    	r=sc.nextFloat();
    }
    //Calculate area
    void calculateArea() {
    	float pi = 3.14159f;
    	a=pi*r*r;
    }
    void displayArea() {
    	System.out.println("Area of circle of radius"+r+" is "+a);
    }
}

public class EncapsulationAssignment {

	public static void main(String[] args) {
		AreaCircle1 a1 = new AreaCircle1();
		AreaCircle1 a2 = new AreaCircle1();
		AreaCircle1 a3 = new AreaCircle1();

		 a1.inputData();
		 a1.displayArea();
		 
		 a2.inputData();
		 a2.displayArea();
		 
		 a3.inputData();
		 a3.displayArea();
	}

}
