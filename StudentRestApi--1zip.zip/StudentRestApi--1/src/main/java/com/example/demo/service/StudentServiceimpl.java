package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.demo.entity.Student;
import com.example.demo.repository.StudentRepository;
@Service
public class StudentServiceimpl implements StudentService{

	@Autowired
	private StudentRepository studentRepository;

	@Override
	public Student studentSave(Student student) {
		
		return studentRepository.save(student);
	}

	@Override
	public List<Student> getAllStudents() {
		
		return studentRepository.findAll();
	}

	@Override
	public Student getstudentbyid(Long sid) {
		
		return studentRepository.findById(sid).get();
	}

	@Override
	public void deleteStudentById(Long sid) {
		
		studentRepository.deleteById(sid);
	}

	@Override
	public Student updatestudentbyid(Student student) {
		
		return studentRepository.save(student);
	}

	



}
