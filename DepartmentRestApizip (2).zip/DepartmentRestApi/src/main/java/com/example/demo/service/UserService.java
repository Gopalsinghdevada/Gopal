package com.example.demo.service;

import org.springframework.http.ResponseEntity;

import com.example.demo.entity.User;

public interface UserService {

	User createUser(User user);

	User enrolledUserToDepartment(Integer uid, Long did);



}
