package com.example.demo.service;

import com.example.demo.entity.Department;

public interface DepartmentService {

	Department departmentSave(Department department);


}
