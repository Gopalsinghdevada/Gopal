package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Department;
import com.example.demo.entity.User;
import com.example.demo.repository.DepartmentRepository;
import com.example.demo.repository.UserRepository;

@Service
public class UserServiceimpl implements UserService{

	@Autowired
	private UserRepository userRepository;
	@Autowired
	private DepartmentRepository departmentRepository;
	
	@Override
	public User createUser(User user) {
		
		return userRepository.save(user);
	}

	@Override
	public User enrolledUserToDepartment(Integer uid, Long did) {
        User user=userRepository.findById(uid).get();
        Department dept=departmentRepository.findById(did).get();
        user.enrolleddepartment(dept);
		return userRepository.save(user);
	}

}
