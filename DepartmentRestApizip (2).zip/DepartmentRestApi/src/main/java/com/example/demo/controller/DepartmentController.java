package com.example.demo.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Department;
import com.example.demo.service.DepartmentService;

@RestController
public class DepartmentController {
//inject an object of departmentservice using @autowired annotation
	@Autowired
	private DepartmentService departmentservice;
	
	//insert records into department table
	//save
	
	@PostMapping("/adddepartment")
	public ResponseEntity<Department> departmentSave(@Valid @RequestBody Department department) {
		Department savedept= departmentservice.departmentSave(department);
		return new ResponseEntity<Department>(savedept, HttpStatus.CREATED);
	}
	
	
}
