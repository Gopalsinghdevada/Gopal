package com.edu.preparedjdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class UpdateUsingPrepared {

	public static void main(String[] args) {
		String driver="com.mysql.cj.jdbc.Driver";
		String url="jdbc:mysql://localhost:3306/edubridgedatabase";
		String un="root";
		String up="root";
		int stdid;
		Connection conn=null;
		ResultSet rs=null;
		PreparedStatement pst=null;
		String n;
		int stid;
		Scanner sc=new Scanner(System.in);
		try {
			Class.forName(driver);
			conn=DriverManager.getConnection(url,un,up);
			System.out.println("Enter student id to update record");
			stdid=sc.nextInt();
			System.out.println("Enter name to change");
			String sn=sc.next();
			
			//check for student existence
			String sel="select * from student1 where sid=?";
			pst=conn.prepareStatement(sel);
			
			pst.setInt(1, stdid);
			rs=pst.executeQuery();
			if(rs.next()) {
				//if record exists then go for update
				String upd="update student1 set sname=? where sid=?";
				pst=conn.prepareStatement(upd);
				pst.setString(1, sn);
				pst.setInt(2, stdid);
				
				int retval=pst.executeUpdate();
				if(retval>0) {
					System.out.println("Student changed successfully");
					}
				else {
					System.out.println("Error");
				}
			}else {
				System.out.println(stdid+" not exists for updating record");
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		

	}

}
