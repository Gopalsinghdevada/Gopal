package com.edu.preparedjdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class DeleteUsingPrepared {

	public static void main(String[] args) {
		String driver="com.mysql.cj.jdbc.Driver";
		String url="jdbc:mysql://localhost:3306/edubridgedatabase";
		String un="root";
		String up="root";
		int stdid;
		Connection conn=null;
		ResultSet rs=null;
		PreparedStatement pst=null;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Student id to delete record");
		stdid=sc.nextInt();
		try {
			Class.forName(driver);
			conn=DriverManager.getConnection(url,un,up);
			String sel="Select * from student1 where sid=?";
			pst=conn.prepareStatement(sel);
			pst.setInt(1, stdid);
			rs=pst.executeQuery();
	          if(rs.next()) { //if this statement is true means record exists
	        	  String del="delete from student1 where sid="+stdid;
	        	  int retval=pst.executeUpdate(del);
	        	  if(retval>0) {
	        		  System.out.println("Record is deleted");
	        	  }else {
	        		  System.out.println("Error!!!! occurred");
	        	  }
	          }else {
	        	  System.out.println(stdid+" not exixts");
	          }
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

}
