package com.edu.preparedjdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class RetrieveRecordPrepared {

	public static void main(String[] args) {
		String driver = "com.mysql.cj.jdbc.Driver";
		String url="jdbc:mysql://localhost:3306/edubridgedatabase";
		String un="root";
        String up="root";
        
        Connection conn=null;
        PreparedStatement pst;
        ResultSet rs=null;
        
        try {
        	Class.forName(driver); //load the driver at run time, register 
			conn = DriverManager.getConnection(url,un,up); //create the connection
			String sel="Select * from student1";
			pst=conn.prepareStatement(sel);
			rs=pst.executeQuery();
			System.out.println("sid\tsname\tcid\tsfees\tsdate");
			while(rs.next()) {
				int id=rs.getInt("sid");
				String sn=rs.getString("sname");
				int cd=rs.getInt("cid");
				float fees=rs.getFloat("sfees");
				
				String dob=rs.getString("sdate");
				System.out.println(id+"\t"+sn+"\t"+cd+"\t"+fees+"\t"+dob);
			}
        	
        }catch(Exception e) {
        	e.printStackTrace();
        }
        

	}

}
