package com.edu.preparedjdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class PreparedStJdbc {

	public static void main(String[] args) {
		String driver = "com.mysql.cj.jdbc.Driver";
		String url="jdbc:mysql://localhost:3306/edubridgedatabase";
		String un="root";
        String up="root";
        Connection conn=null;
        PreparedStatement pst;
        ResultSet rs=null;
        
        int sid ,cid;
        String sname;
        String sdate;
        float sfees;
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter student name");
        sname=sc.next();
        System.out.println("Enter student id");
        sid=sc.nextInt();
        System.out.println("Enter cid");
        cid=sc.nextInt();
        System.out.println("Enter sfees");
        sfees=sc.nextFloat();
        System.out.println("Enter DOB");
        sdate=sc.next();
        
        try {
			Class.forName(driver); //load the driver at run time, register 
			conn = DriverManager.getConnection(url,un,up); //create the connection
			String s="insert into student1 values(?,?,?,?,?)";
			pst=conn.prepareStatement(s);
			pst.setInt(1, sid);
			pst.setString(2, sname);
			pst.setInt(3, cid);
			pst.setString(4, sdate);
			pst.setFloat(5, sfees);
			
			
			int rv=pst.executeUpdate();
			if(rv>0) {
				System.out.println("Record is inserted");
			}
			else {
				System.out.println("Not inserted");
			}
			
	}catch(Exception e) {
		e.printStackTrace();
	}
        
		

	}

}
