package com.edu.preparedjdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class DeletePreparedStatement1 {

	public static void main(String[] args) {
		String driver="com.mysql.cj.jdbc.Driver";
		String url="jdbc:mysql://localhost:3306/edubridgedatabase";
		String un="root";
		String up="root";
		
		Connection conn=null;
		PreparedStatement pst=null;
		ResultSet rs = null;
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter student id to delete");
		int stid=sc.nextInt();
		
		try {
			Class.forName(driver);
			conn=DriverManager.getConnection(url,un,up);
			String sel="Select * from student1 where sid=?";
			pst=conn.prepareStatement(sel);
			pst.setInt(1, stid);
			rs=pst.executeQuery();
			if(rs.next()) {
			
			String del="delete from student1 where sid=?";
			pst=conn.prepareStatement(del);
			pst.setInt(1, stid);
		
			int retval=pst.executeUpdate();
			if(retval>0) {
				System.out.println("Record is deleted");
			}else {
				System.out.println("Error");
			}
		}else {
			System.out.println("Student id not exists");
		}
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}

}
