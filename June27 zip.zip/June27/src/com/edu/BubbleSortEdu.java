package com.edu;

import java.util.Scanner;

class BubbleSort{
	int arr[],size,i;
	
	void inputData() {
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter size of array");
		size=sc.nextInt();
		arr=new int[size];
		System.out.println("Enter "+size+"array element" );
		for(int i=0;i<size;i++) {
			arr[i]=sc.nextInt();
		}
	
	}
	public void sortData() {
		int temp,j;
		for( i=0;i<size;i++) {
			for(j=0;j<size-1-i;j++) {
				if(arr[j]>arr[j+1]) {
					temp=arr[j];
					arr[j]=arr[j+1];
					arr[j+1]=temp;
				}
			}
		}
		System.out.println("Sorted array elements are");
		for(int i=0;i<size;i++) {
			System.out.println(arr[i]);
		}
	}

}




public class BubbleSortEdu {

	public static void main(String[] args) {
		BubbleSort buo=new BubbleSort();
		buo.inputData();
		buo.sortData();

	}

}
