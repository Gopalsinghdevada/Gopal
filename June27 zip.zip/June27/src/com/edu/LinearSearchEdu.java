package com.edu;

import java.util.Scanner;

class ArrayOperationsLinearSearch{
	int a[];
	int size;
	int find;
	public void inputData() {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter size");
		size=sc.nextInt();
		a=new int[size];
		System.out.println("Enter array elements"+a.length);
		for(int  i=0;i<a.length;i++) {
			a[i]=sc.nextInt();
		}
		System.out.println("array elements are");
		for(int i:a){
			System.out.println(i);
		}
		System.out.println("Enter search element");
		find=sc.nextInt();
		
	}
	public void linearSearch() {
		int pos=-1;
		for(int i=0;i<size;i++) {
			if(find==a[i]) {
			pos=i; //pos=1
			break;
		}
	}
		if(pos >= 0) {
			System.out.println("Successful search");
			System.out.println(find+" found at position "+(pos+1));
			
		}
		else {
			System.out.println("Unsuccessful search");
			System.out.println("Element not found");
		}
	}
	
}

public class LinearSearchEdu {

	public static void main(String[] args) {
		ArrayOperationsLinearSearch aob =new ArrayOperationsLinearSearch();
		 aob.inputData();
		 aob.linearSearch();
	}

}
