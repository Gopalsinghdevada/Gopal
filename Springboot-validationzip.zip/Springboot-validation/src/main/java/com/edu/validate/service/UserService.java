package com.edu.validate.service;

import com.edu.validate.entity.User;

public interface UserService {

	User createUser(User user);

}
