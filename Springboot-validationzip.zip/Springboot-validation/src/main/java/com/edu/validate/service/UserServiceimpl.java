package com.edu.validate.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.edu.validate.entity.User;
import com.edu.validate.repository.UserRepository;

@Service
public class UserServiceimpl implements UserService{

	@Autowired
	private UserRepository userRepository;
	
	@Override
	public User createUser(User user) {
		
		return userRepository.save(user);
	}

}
