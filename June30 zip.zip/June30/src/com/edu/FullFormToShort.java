package com.edu;

public class FullFormToShort {

	public static void main(String[] args) {
		
		String s="VITAL INFORMATION RESOURCE UNDER SEIZE";
		String s1="";
		s1=s1+s.charAt(0);
		for(int i=0;i<s.length();i++) {
			char ch=s.charAt(i);
			if(ch==' ') {
				s1=s1+s.charAt(i+1);
			}
			
		}
		System.out.println(s1);
	}

}
