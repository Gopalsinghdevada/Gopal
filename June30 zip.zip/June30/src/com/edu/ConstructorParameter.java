package com.edu;

public class ConstructorParameter {

	int a,b,s; //instance variables
	//Constructor is a special method , its name is class name itself and it does not 
	//have return type
	ConstructorParameter(){ //constructor
		a=10;
		b=56;
		System.out.println("Constructor is called");
		System.out.println("Constructor is used to initialize the member data of the class");
	}
	ConstructorParameter(int i,int j){
		System.out.println("Constructor with arg are called");
		a=i;
		b=j;
	}
	void add() {//method
		s=a+b;
		System.out.println("s="+s);
	}


	public static void main(String[] args) {
		ConstructorParameter ob = new ConstructorParameter();
		ConstructorParameter ob1 = new ConstructorParameter();
		ob.add();
		ob1.add();
		ConstructorParameter ob2 = new ConstructorParameter(6,9);
		ConstructorParameter ob3 = new ConstructorParameter(6,10);
		ob2.add();
		ob3.add();


	}

}
