package com.edu;

public class ReplaceVowels {

	public static void main(String[] args) {
		String s="TATA STEEL IS IN JAMSHEDPUR";
		String str="";
		for(int i=0;i<s.length();i++)
		{
			char ch=s.charAt(i);
			if(s.charAt(i)=='A' || s.charAt(i)=='E' || s.charAt(i)=='I' || s.charAt(i)=='O' || s.charAt(i)=='U') {
			str=str+"*";
			
			}else {
				str=str+ch;
     			}
		}
        System.out.println(str);
	}

}
