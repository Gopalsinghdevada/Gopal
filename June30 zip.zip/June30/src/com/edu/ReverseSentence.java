package com.edu;

import java.util.Scanner;

public class ReverseSentence {

	public static void main(String[] args) {
		String s="Computer is Fun";
       s=" "+s;
       String s1="";
       
       for(int i=s.length()-1;i>=0;i--) {
    	   char ch=s.charAt(i);
    	   if(ch==' ') {
    		   System.out.print(s1+" ");
    		   s1="";
    	   }else {
    		   s1=ch+s1;
    	   }
       }
       
	}

}
