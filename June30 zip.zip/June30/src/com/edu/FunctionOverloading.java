package com.edu;

class Overloading{
	void display() {
		System.out.println("No arguments ");
	}
	void display(int i) {
		System.out.println("int  arguments ");
	}
	void display(float i) {
		System.out.println(" arguments float ");
	}
	void display(double i) {
		System.out.println(" arguments double ");
	}
	void display(char i) {
		System.out.println(" arguments char ");
	}
	void display(int i, int j) {
		System.out.println("two arguments");
	}
	void display(int i,float j) {
		System.out.println("two arguments with different datatypes");
		
	}
	void display(float j,int i) {
		System.out.println("by interchanging arguments");
	}
}

public class FunctionOverloading {

	public static void main(String[] args) {
		Overloading ob=new Overloading();
		ob.display();
		ob.display(56);
		ob.display(5.6f);
		ob.display(7.9);
		ob.display('A');
		ob.display(5,8);
		ob.display(4,6.7f);
		ob.display(8.9f,7);
	}

}
