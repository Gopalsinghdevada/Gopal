package com.edu;

public class Constructor {

	   int a,b,s;
	   Constructor(){
		   a=10;
		   b=56;
		   System.out.println("Constructor is called");
		   System.out.println("Constructor is used to  intialize the member data of the class");
	   }
	   void add() {
		   s=a+b;
		   System.out.println(s);
	   }
	public static void main(String[] args) {
		Constructor ob = new Constructor();
		Constructor ob1 = new Constructor();
		ob.add();
		ob1.add();

	}

}
