package com.edu;

class AddOverloading{
 
	
	void add(int i, int j) {
		System.out.println("integer addition "+(i+j));
	}
	void add(float i,float j) {
		System.out.println("float addition "+(i+j));
		
	}
	void add(double i,double j) {
		System.out.println("double addition "+(i+j));
	}
	void add(short i, short j) {
		System.out.println("short type add "+(i+j));
	}
	void add(byte i, byte j) {
		System.out.println("Byte type add "+(i+j));
	}
}

public class AddOverload {

	public static void main(String[] args) {
		AddOverloading s=new AddOverloading();
		s.add(5,6);
        s.add(5.1f, 7.2f);
        s.add(55.48, 448.2);
        s.add((short)7, (short)9);
        s.add((byte)8, (byte)5);
	}

}
