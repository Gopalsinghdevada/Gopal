package com.edu;

public class StringBuilder {

	public static void main(String[] args) {
	 
				String s="Edubridge";
				
		        StringBuilder sb=new StringBuilder(s);
		        System.out.println(sb.reverse());
		        System.out.println(((Appendable) sb).append("India"));
			}

}
