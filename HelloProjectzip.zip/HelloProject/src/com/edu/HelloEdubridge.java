package com.edu;

public class HelloEdubridge {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
                   System.out.println("Hello Gopalsingh");
                   System.out.println("Pune-39, Maharashtra");
                   System.out.println("8888787437");
                   System.out.println(9+8+ "Edubridge");
	
		
	}

}
