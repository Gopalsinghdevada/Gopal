package com.edu;

public class ForLoopRevision {

	public static void main(String[] args) {
	int i;
	System.out.println("Reverse number");
	for(i=10;i>=1;i--) {
		System.out.println(i);
		
	}

	}

}
