package com.edu;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

public class MainStudentAddress {

	public static void main(String[] args) {
		Configuration config=new Configuration().configure().addAnnotatedClass(StudentOneToOne.class).addAnnotatedClass(AddressOneToOne.class);
		ServiceRegistry reg = new ServiceRegistryBuilder().applySettings(config.getProperties()).buildServiceRegistry();
		SessionFactory sf=config.buildSessionFactory(reg);
		Session session = sf.openSession();
		Transaction tx=session.beginTransaction();
		
		AddressOneToOne addob1=new AddressOneToOne();
		StudentOneToOne studob1=new StudentOneToOne();
        
		addob1.setAddcross("Rajgurunagar");
		addob1.setAddstreet("Moshi");
		
		studob1.setSname("Suresh");
		studob1.setSage(20);
		studob1.setAddr(addob1);
		
		session.save(addob1);
	    session.save(studob1);
	    tx.commit();
	}

}
