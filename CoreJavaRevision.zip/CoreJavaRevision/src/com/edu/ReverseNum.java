package com.edu;

import java.util.Scanner;

public class ReverseNum {

	public static void main(String[] args) {
		int n ,rev=0,rem,temp,digit=0;
		Scanner sc=new Scanner(System.in);
	
		System.out.println("Enter the number");
		n=sc.nextInt();
		temp=n;
        while(n!=0) {
        	//rem=n%10;
        	//rev=rev*10 + rem;
        	n=n/10;
        	digit++;
        	}
        System.out.println(digit);
       // System.out.println("Reverse number is "+rev);
       // if(temp==rev) 
       // 	System.out.println("palindrome number");
       // else
        //	System.out.println("not palindrome");
	}

}
