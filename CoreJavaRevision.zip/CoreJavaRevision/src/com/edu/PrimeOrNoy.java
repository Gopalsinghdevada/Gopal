package com.edu;

import java.util.Scanner;
class check{
public static void checkPrime() {
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter a number");
	int num=sc.nextInt();
	int c=0;
	for(int i=1;i<=num;i++) {
		if(num%i==0) {
			c=c+1;
			
		}
	}
	if(c==2) {
		System.out.println(num+" is aprime");
	}else {
		System.out.println(num+" is not prime");
	}
}
}
public class PrimeOrNoy {
	public static void main(String[] args) {
		check pob=new check();
		pob.checkPrime();

	}

}
