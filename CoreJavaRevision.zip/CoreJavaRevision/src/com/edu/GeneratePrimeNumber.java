package com.edu;

import java.util.Scanner;

class Generate{
	public void inputdata() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter starting number");
		int nfirst=sc.nextInt();
		System.out.println("Enter end number");
		int nlast=sc.nextInt();
		int c=0;
		for(int i=nfirst;i<=nlast;i++) {
			c=0;
			for(int j=1;j<=i;j++) {
				if(i%j==0) {
					c=c+1;
					
				}
			}
			if(c==2) {
				System.out.println(i+" is aprime");
			}else {
				System.out.println(i+" is not prime");
			}
		}
		
		}
	}


public class GeneratePrimeNumber {

	public static void main(String[] args) {
		Generate pob=new Generate();
		pob.inputdata();

	}

}
