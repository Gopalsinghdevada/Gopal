package com.edu;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

public class EmployeeMain {

	public static void main(String[] args) {
		Configuration confg=new Configuration().configure().addAnnotatedClass(Employee.class);
		ServiceRegistry reg= new ServiceRegistryBuilder().applySettings(confg.getProperties()).buildServiceRegistry();
		SessionFactory sf=confg.buildSessionFactory(reg);
		Session session = sf.openSession();
		Transaction tx=session.beginTransaction();
		/*
		Employee eob=new Employee();//new obj need to be created for new employee 
		
        eob.setEmployeeName("Raj");
		eob.setEmployeeAge(23);
        eob.setEmployeeDept("IT");
        eob.setEmployeeSalary(42000);
        session.save(eob);
        //tx.commit();
Employee eob1=new Employee();//new obj need to be created for new employee 
		
        eob1.setEmployeeName("Raj1");
		eob1.setEmployeeAge(23);
        eob1.setEmployeeDept("IT");
        eob1.setEmployeeSalary(42000);
        session.save(eob1);
        tx.commit();
        */
        //get record by id
       Employee eob2 = (Employee) session.get(Employee.class,9);
       System.out.println(eob2);
       
       //fetch all records
       Query q=session.createQuery("from Employee");
       List<Employee> lst=q.list();
       
       //iterator
       Iterator <Employee> it=lst.iterator();
       System.out.println("ID\tEname\tEage\tEsalary\tEdept");
       while(it.hasNext()) {
    	   Employee eob4=it.next();
    	   System.out.println(eob4.getEmployeeId()+"\t"+eob4.getEmployeeName()+"\t"+eob4.getEmployeeAge()+"\t"+eob4.getEmployeeSalary()+"\t"+eob4.getEmployeeDept());
     }
    	   //update record change name 
    	   Query q1=session.createQuery("update Employee set employeeName=:n where employeeId=:i");
    	   q1.setParameter("n", "poovi");
    	   q1.setParameter("i", 7);
    	   int i=q1.executeUpdate();
    	   if(i>0) {
    		   System.out.println("Record is updated");
    	   }else {
    		   System.out.println("Not updated");
    	   }
    	   //delete record
    	   Query q2=session.createQuery("delete from Employee where employeeId=:j");
    	  
    	   q2.setParameter("j", 1);
    	   int j=q2.executeUpdate();
    	   if(j>0) {
    		   System.out.println("Record is updated");
    	   }else {
    		   System.out.println("Not updated");
    	   }
    	   tx.commit();
       
       }
	}


