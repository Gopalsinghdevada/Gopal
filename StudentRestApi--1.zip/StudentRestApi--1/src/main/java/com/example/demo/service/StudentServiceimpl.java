package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.demo.entity.Student;
import com.example.demo.error.StudentNotFoundException;
import com.example.demo.repository.StudentRepository;
@Service
public class StudentServiceimpl implements StudentService{

	@Autowired
	private StudentRepository studentRepository;

	@Override
	public Student studentSave(Student student) {
		
		return studentRepository.save(student);
	}

	@Override
	public List<Student> getAllStudents() {
		
		return studentRepository.findAll();
	}

	@Override
	public Student getstudentbyid(Long sid) throws StudentNotFoundException {
		
		//return studentRepository.findById(sid).get();
	Optional<Student> student=studentRepository.findById(sid);
	if(!student.isPresent()) 
		throw new StudentNotFoundException("Student Id not found");
	return student.get();
	}

	@Override
	public void deleteStudentById(Long sid) throws StudentNotFoundException {
		
		//studentRepository.deleteById(sid);
		Optional<Student> student=studentRepository.findById(sid);
		if(!student.isPresent())
			throw new StudentNotFoundException("Student id is not present");
		studentRepository.deleteById(sid);
	}

	@Override
	public Student updatestudentbyid(Long sid, Student student) throws StudentNotFoundException {
		Optional<Student> stob1=studentRepository.findById(sid);
		if(!stob1.isPresent())
			throw new StudentNotFoundException("Student id is not present");
		else {
		Student stob=studentRepository.findById(sid).get();
		
		if(student.getStudentname()!=null)
			
			stob.setStudentname(student.getStudentname());
		if(student.getStudentemailid()!=null)
			stob.setStudentemailid(student.getStudentemailid());
		if(student.getStudentfees()!= 0)
			stob.setStudentfees(student.getStudentfees());
			
		return studentRepository.save(stob);
		}
	}

	@Override
	public Student findStudentByName(String sname) {
		
		return studentRepository.findByStudentname(sname);
	}

	@Override
	public Student findStudentByEmailId(String semail) {
		
		return studentRepository.findByStudentemailid(semail);
	}

	



}
