package com.example.demo.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Student {
@Id
@GeneratedValue(strategy = GenerationType.AUTO)
	private Long studentId;
	private String studentname;
	private float studentfees;
	private String studentemailid;
	public Long getStudentId() {
		return studentId;
	}
	public void setStudentId(Long studentId) {
		this.studentId = studentId;
	}
	public String getStudentname() {
		return studentname;
	}
	public void setStudentname(String studentname) {
		this.studentname = studentname;
	}
	public float getStudentfees() {
		return studentfees;
	}
	public void setStudentfees(float studentfees) {
		this.studentfees = studentfees;
	}
	public String getStudentemailid() {
		return studentemailid;
	}
	public void setStudentemailid(String studentemailid) {
		this.studentemailid = studentemailid;
	}
	
	
}
