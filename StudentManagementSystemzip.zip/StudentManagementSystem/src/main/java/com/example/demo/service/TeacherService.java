package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Teacher;
import com.example.demo.error.TeacherNotFoundException;

public interface TeacherService {

	List<Teacher> getAllTeacher();

	Teacher addTeacher(Teacher teacher);

	void deletebyteacherid(Integer tid) throws TeacherNotFoundException;

}
