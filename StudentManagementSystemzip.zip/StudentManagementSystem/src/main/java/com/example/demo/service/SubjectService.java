package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Subject;
import com.example.demo.error.SubjectNotFoundException;

public interface SubjectService {

	List<Subject> getSubject();

   Subject addSubjects(Subject subject);
  
   Subject enrolledStudentToSubject(Integer subid, Integer stuid);

Subject assignSubjectToTeacher(Integer subid, Integer tid);

void deleteSubjectById(Integer subid) throws SubjectNotFoundException;

}
