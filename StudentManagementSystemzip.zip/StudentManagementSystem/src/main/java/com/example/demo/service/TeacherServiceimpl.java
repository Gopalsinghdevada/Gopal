package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Teacher;
import com.example.demo.error.TeacherNotFoundException;
import com.example.demo.repository.TeacherRepository;
@Service
public class TeacherServiceimpl implements TeacherService{

	@Autowired
	private TeacherRepository teacherRepository;
	@Override
	public List<Teacher> getAllTeacher() {
		
		return teacherRepository.findAll();
	}
	@Override
	public Teacher addTeacher(Teacher teacher) {
		
		return teacherRepository.save(teacher);
	}
	@Override
	public void deletebyteacherid(Integer tid) throws TeacherNotFoundException {
		Optional<Teacher> teacher=teacherRepository.findById(tid);
		if(!teacher.isPresent())
			throw new TeacherNotFoundException("Teacher id not found for deletion");
		 teacherRepository.deleteById(tid);
		
	}

}
