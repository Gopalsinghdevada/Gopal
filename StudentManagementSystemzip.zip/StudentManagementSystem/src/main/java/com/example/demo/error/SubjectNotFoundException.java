package com.example.demo.error;

public class SubjectNotFoundException extends Exception{

	public SubjectNotFoundException(String message) {
		super(message);
	}
}
