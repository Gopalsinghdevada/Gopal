package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Teacher;
import com.example.demo.error.TeacherNotFoundException;
import com.example.demo.service.TeacherService;

@RestController
public class TeacherController {

	@Autowired
	private TeacherService teacherservice;
	
	@GetMapping("/getteachers")
	public List<Teacher> getAllTeacher(){
		return teacherservice.getAllTeacher();
	}
	@PostMapping("/addteacher")
	public Teacher addTeacher(@RequestBody Teacher teacher) {
		return teacherservice.addTeacher(teacher);
	}
	@DeleteMapping("/deleteteacher/{tid}")
	public String deletebyteacherid(@PathVariable("tid") Integer tid) throws TeacherNotFoundException {
		teacherservice.deletebyteacherid(tid);
		return "Record deleted successfully";
	}
}
