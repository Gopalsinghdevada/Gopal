package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Student;
import com.example.demo.error.StudentNotFoundException;
import com.example.demo.service.StudentService;

@RestController
public class StudentController {

	@Autowired
	private StudentService studentservice;
	
	@GetMapping("/getstudents")
	public List<Student> getAllStudent(){
		return studentservice.getAllStudent();
	}
	@PostMapping("/addstudents")
	public Student addstudent(@RequestBody Student student) {
		return studentservice.addstudent(student);
	}
	@DeleteMapping("/deletestudentbyid/{stuid}")
	public String deleteStudentById(@PathVariable("stuid") Integer stuid) throws StudentNotFoundException {
		studentservice.deleteStudentById(stuid);
		return "Record deleted successfully";
	}
	
	
}
