package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Student;
import com.example.demo.error.StudentNotFoundException;
import com.example.demo.repository.StudentRepository;

@Service
public class StudentServiceimpl implements StudentService{

	@Autowired
	private StudentRepository studentRepository;
	
	@Override
	public List<Student> getAllStudent() {
		
		return studentRepository.findAll();
	}

	@Override
	public Student addstudent(Student student) {
		
		return studentRepository.save(student);
	}

	@Override
	public void deleteStudentById(Integer stuid) throws StudentNotFoundException {
		Optional<Student> student=studentRepository.findById(stuid);
		if(!student.isPresent())
			throw new StudentNotFoundException("Student is not present for deletion"); 
		studentRepository.deleteById(stuid);
	}

}
