package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Subject;
import com.example.demo.error.SubjectNotFoundException;
import com.example.demo.service.SubjectService;

@RestController
public class SubjectController {

	@Autowired
	private SubjectService subjectservice;
	
	@GetMapping("/getsubjects")
	public List<Subject> getSubject(){
		return subjectservice.getSubject();
	}
	
	@PostMapping("/addsubject")
	public Subject addSubjects(@RequestBody Subject subject) {
		return subjectservice.addSubjects(subject);
	}
	//update
	@PutMapping("/subject/{subid}/students/{stuid}")
	public Subject enrolledStudentToSubject(@PathVariable("subid") Integer subid,@PathVariable("stuid") Integer stuid) {
	   return subjectservice.enrolledStudentToSubject(subid, stuid);
	}
	//assign subject to teacher
	
	@PutMapping("/teacher/{tid}/subject/{subid}")
	public Subject assignSubjectToTeacher(@PathVariable("subid") Integer subid, @PathVariable("tid") Integer tid) {
		return subjectservice.assignSubjectToTeacher(subid, tid);
	}
	
	@DeleteMapping("/deletesubjectbyid/{subid}")
	public String deleteSubjectById(@PathVariable("subid") Integer subid) throws SubjectNotFoundException {
		subjectservice.deleteSubjectById(subid);
		return "Record deleted successfully";
	}
}
