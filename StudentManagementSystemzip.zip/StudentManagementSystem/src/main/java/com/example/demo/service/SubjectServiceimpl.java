package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Student;
import com.example.demo.entity.Subject;
import com.example.demo.entity.Teacher;
import com.example.demo.error.SubjectNotFoundException;
import com.example.demo.repository.StudentRepository;
import com.example.demo.repository.SubjectRepository;
import com.example.demo.repository.TeacherRepository;

@Service
public class SubjectServiceimpl implements SubjectService{

	@Autowired
	private SubjectRepository subjectRepository;
	@Autowired
	private StudentRepository studentRepository;
	@Autowired
	private TeacherRepository teacherRepository;
	@Override
	public List<Subject> getSubject() {
		
		return subjectRepository.findAll();
	}
	@Override
	public Subject addSubjects(Subject subject) {
		
		return subjectRepository.save(subject);
	}
	@Override
	public Subject enrolledStudentToSubject(Integer subid, Integer stuid) {
		Subject subject=subjectRepository.findById(subid).get();
		Student student=studentRepository.findById(stuid).get();
		subject.enrolledstudent(student);
		return subjectRepository.save(subject);
	}
	@Override
	public Subject assignSubjectToTeacher(Integer subid, Integer tid) {
		Subject subject=subjectRepository.findById(subid).get();
		Teacher teacher=teacherRepository.findById(tid).get();
		subject.assignTeacher(teacher);
		return subjectRepository.save(subject);
	}
	@Override
	public void deleteSubjectById(Integer subid) throws SubjectNotFoundException {
		Optional<Subject> subject=subjectRepository.findById(subid);
		if(!subject.isPresent())
			throw new SubjectNotFoundException("Subject not found for deletion");
		subjectRepository.deleteById(subid);
		
	}


}
