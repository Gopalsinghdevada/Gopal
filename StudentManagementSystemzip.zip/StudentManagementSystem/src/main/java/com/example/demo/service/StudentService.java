package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Student;
import com.example.demo.error.StudentNotFoundException;

public interface StudentService {

	List<Student> getAllStudent();

	Student addstudent(Student student);

	void deleteStudentById(Integer stuid) throws StudentNotFoundException;

}
