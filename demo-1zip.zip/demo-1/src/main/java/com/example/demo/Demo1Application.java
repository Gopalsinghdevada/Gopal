package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
public class Demo1Application {

	public static void main(String[] args) {
		ConfigurableApplicationContext ctx= SpringApplication.run(Demo1Application.class, args);
	      Employee eob=ctx.getBean("employee",Employee.class);
	      Employee eob1=ctx.getBean("employee",Employee.class);
	      eob.display();
	      eob1.display();
	      System.out.println("eob="+eob);
	      System.out.println("eob1="+eob1);
	}

}
