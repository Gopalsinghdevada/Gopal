package com.edu.operations;

import java.sql.SQLException;
import java.util.Scanner;

public class JdbcMainClass {

	public static void main(String[] args) throws SQLException {
		Scanner sc=new Scanner(System.in);
		int choice;
		char ch;
		while(true) {
		System.out.println("************MENU Please order sir************");
		System.out.println("Database operation");
		System.out.println("Enter your choice");
		System.out.println("1.Display Student");
		System.out.println("2.Add Student");
		System.out.println("3.Delete Student based on student id");
		System.out.println("4.Update Student");
		
		choice =sc.nextInt();
		switch(choice) {
		case 1: //display
		    System.out.println("display all students");
		    OperationOfJdbc.displayStudents();
		    break;
	case 2: //add students
		     System.out.println("Add new student");
		     OperationOfJdbc.insertdata();
		    break;
	case 3: //delete based on id
		      System.out.println("delete student based on id");
		      OperationOfJdbc.DeleteRecord();
		   break; 
	case 4://update
		    System.out.println("update student");
		       OperationOfJdbc.UpdateRecord();
		     break;
	 default: System.out.println("Invalid input");
	}
	System.out.println("Do want to continue y/n");
	ch=sc.next().charAt(0);
	if(ch=='n' || ch=='N')
		break;
	}
	System.out.println("Your program is terminated");
}
}
	
