package com.edu.operations;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class OperationOfJdbc {
	private static Connection myconn; 
	private static Statement st;
	private static ResultSet rs;
	public static void displayStudents() throws SQLException {
		myconn=DataBaseConnectionClass.getConnection();
		st=myconn.createStatement();
		String sel="select * from student1";
    	
    	rs=st.executeQuery(sel);
    	System.out.println(rs);
    	System.out.println("sid\tsname\tcid\tsdate\tsfees");
    	
    	while(rs.next()) {
    	   
    		int sn=rs.getInt(1);//or rs.getInt("sid");
    		String sname=rs.getString(2);
    		int cid=rs.getInt(3);
    		String sdate=rs.getString(4);
    		float sfees=rs.getFloat(5);
    		System.out.println(sn+"\t"+sname+"\t"+cid+"\t"+sdate+"\t"+sfees);
    		}
	}
	public static void insertdata() throws SQLException {
		myconn=DataBaseConnectionClass.getConnection();
		st=myconn.createStatement();
		  int sid ,cid;
	        String sname;
	        String sdate;
	        float sfees;
	        Scanner sc=new Scanner(System.in);
	        System.out.println("Enter student name");
	        sname=sc.next();
	        System.out.println("Enter student id");
	        sid=sc.nextInt();
	        System.out.println("Enter cid");
	        cid=sc.nextInt();
	        System.out.println("Enter sfees");
	        sfees=sc.nextFloat();
	        System.out.println("Enter DOB");
	        sdate=sc.next();
	        
	       
			//check record exists
			String sel="select * from student1 where sid="+sid;
			rs=st.executeQuery(sel);
			if(rs.next()){
				System.out.println(sid+" already exists");
			}else {
			
			
			String ins="insert into student1 values("+sid+",'"+sname+"',"+cid+",'"+sdate+"',"+sfees+")";
			System.out.println(ins);
			int rval=st.executeUpdate(ins);//for insert , update and delete use exceuteUpdate
			if(rval>0) {
				System.out.println("Record is added");
			}
			else {
				System.out.println("Error Occurred");
			}
			}
	}
    public static void UpdateRecord() throws SQLException {
    	String n,db;
		int stid;
		Scanner sc=new Scanner(System.in);
		char ch;
	
		System.out.println("Enter name to changed");
		n=sc.next();
		System.out.println("Enter student id");
		stid=sc.nextInt();
	
		//check id exists for updating record
		String sel="Select * from student1 where sid= "+stid;
		rs=st.executeQuery(sel);
		if(rs.next()) {
			String upd="update student1 set sname ='"+n+"' where sid="+stid;
			int retval=st.executeUpdate(upd);
			if(retval>0) {
				System.out.println("Student changed successfully");
				}
			else {
				System.out.println("Error");
			}
		}else {
			System.out.println(stid+" not exists for updating record");
		}
		
    }
   public static void DeleteRecord() throws SQLException {
	   int stdid;
	   Scanner sc = new Scanner(System.in);
	
		System.out.println("Enter sid to delete record");
		stdid=sc.nextInt();
		
         String sel="select * from student1 where sid="+stdid;
         rs=st.executeQuery(sel);
         if(rs.next()) { //if this statement is true means record exists
       	  String del="delete from student1 where sid="+stdid;
       	  int retval=st.executeUpdate(del);
       	  if(retval>0) {
       		  System.out.println("Record is deleted");
       	  }else {
       		  System.out.println("Error!!!! occurred");
       	  }
         }else {
       	  System.out.println(stdid+" not exixts");
         }
   }
   

}
