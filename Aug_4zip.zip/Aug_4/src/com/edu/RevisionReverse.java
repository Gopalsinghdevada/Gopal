package com.edu;

import java.util.Scanner;

public class RevisionReverse {

	public static void main(String[] args) {
		int num,rev=0,rem;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter num u want to reverse");
		num=sc.nextInt();
		while(num!=0) {
			rem=num%10;
			rev=rev*10+rem;
			num=num/10;
			
		}
		System.out.println("Reverse num is "+rev);
	}

}
