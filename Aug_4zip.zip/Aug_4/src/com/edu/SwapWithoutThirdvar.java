package com.edu;

public class SwapWithoutThirdvar {

	public static void main(String[] args) {
		int a=10;
		int b=20;
		System.out.println("A= "+a);
		System.out.println("B= "+b);
		a=a+b;
		b=a-b;
		a=a-b;
		System.out.println("Swap A="+a);
		System.out.println("Swap B="+b);
		

	}

}
