package com.edu;

import java.util.Scanner;

public class RevisionLargestOf {

	public static void main(String[] args) {
	  int a,b,c;
	  Scanner sc = new Scanner(System.in);
	  System.out.println("Enter three numbers");
	  a=sc.nextInt();
	  b=sc.nextInt();
	  c=sc.nextInt();
	  if(a>b && a>c) {
		  System.out.println("Largest is "+a);
	  }else if(b>a && b>c) {
		  System.out.println("Largest is "+b);
	  }else if(c>a && c>b) {
		  System.out.println("Largest is "+c);
	  }else {
		  System.out.println("All are equal");
	  }

	}

}
