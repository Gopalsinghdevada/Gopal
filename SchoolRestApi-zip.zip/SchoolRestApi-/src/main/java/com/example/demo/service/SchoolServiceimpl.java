package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.School;
import com.example.demo.repository.SchoolRepository;

@Service
public class SchoolServiceimpl implements SchoolService{

	@Autowired
	private SchoolRepository schoolRepository;
	@Override
	public School schoolSave(School school) {
		return schoolRepository.save(school);
	}

}
