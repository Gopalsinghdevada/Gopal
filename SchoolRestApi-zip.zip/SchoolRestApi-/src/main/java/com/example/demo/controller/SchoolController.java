package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.School;
import com.example.demo.service.SchoolService;

@RestController
public class SchoolController {
//inject an object of schoolservice using autowired anotation
	@Autowired
	private SchoolService schoolservice;
	//insert record using 
	@PostMapping("/addschool")
	public School schoolSave(@RequestBody School school) {
		return schoolservice.schoolSave(school);
	}
}
