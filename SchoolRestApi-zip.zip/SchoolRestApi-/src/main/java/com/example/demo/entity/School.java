package com.example.demo.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class School {
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long rollno;
    private String studname;
    private float studfees;
	public Long getRollno() {
		return rollno;
	}
	public void setRollno(Long rollno) {
		this.rollno = rollno;
	}
	public String getStudname() {
		return studname;
	}
	public void setStudname(String studname) {
		this.studname = studname;
	}
	public float getStudfees() {
		return studfees;
	}
	public void setStudfees(float studfees) {
		this.studfees = studfees;
	}
    

}
