package com.example.demo.service;

import com.example.demo.entity.School;

public interface SchoolService {

	School schoolSave(School school);
}
