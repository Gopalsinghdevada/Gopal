package com.edu;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class HelloGopal
 */
@WebServlet("/HelloGopal")
public class HelloGopal extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public HelloGopal() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	
		System.out.println("Hey Gopal how are u doing?");
		PrintWriter out=response.getWriter();
		String s=request.getParameter("uname");
		String p=request.getParameter("upass");
		out.println("Hello "+s);
		out.println("Your password is :"+p);
		if(s.equalsIgnoreCase("admin") && p.equalsIgnoreCase("admin123")) {
			out.println("Valid user");
		}else {
			out.println("Invalid user");
		}
	}

}
