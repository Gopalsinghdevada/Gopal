package com.edu;

import org.springframework.stereotype.Component;

@Component
public class Student {//object always with lowercase class name
	public void display() {
		System.out.println("I am Display");
	}

}
